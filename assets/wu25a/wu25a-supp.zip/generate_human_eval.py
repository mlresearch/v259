import torch
import os
import pandas as pd
import re
import json
import pickle
import random
from cli import *
# Need to use correct environment for this task.
# Initialize the pipeline once

def load_dictionary_contexts(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"dctxt_bs_{batch_size}_nb_{n_batches}.pt")
    print("Reading in contexts:", dir_path)
    return torch.load(dir_path)




# We c
def create_questions_df(contexts_dict, topk=4):
    df = {"fid": [],  "question1": [], "question2":[], "random_context" : []}
    question1 = "Please identify the context that is different from the other contexts."
    question2 = "Please describe the common pattern observed among the contexts."
    # initialize topk question columns
    for i in range(topk + 1): # + 1 for the random context
        df[f"context{i}"] = []

    for f_id, context_dict in contexts_dict.items():
        df["fid"].append(f_id)
        df["question1"].append(question1)
        df["question2"].append(question2)
        contexts = context_dict["context_string"][:topk]
        random_context = get_random_context(f_id, contexts_dict)
        df["random_context"].append(" ".join(random_context))
        contexts.append(random_context)
        random.shuffle(contexts)
        print(contexts)
        for i in range(topk + 1):
            if i > len(contexts)-1:
                df[f"context{i}"].append(None)
            else:
                df[f"context{i}"].append(" ".join(contexts[i]))
    return pd.DataFrame(df)

def create_yes_no_question(context_strings):
    """
    Create a prompt from the specified list of context strings.

    Args:
        context_strings (list): A list of context strings.

    Returns:
        str: The generated prompt.
    """
    prompt = f""
    for context_string in context_strings:
        prompt += " ".join(context_string) + "\n"
    prompt += f"\nIs there a common pattern observed among these 4 contexts above? Respond with only one word yes or no.\n"
    return prompt

def create_dict_questions_yes_no(contexts_dictionary, topk=4):
    questions = {}
    for f_id, context_dict in contexts_dictionary.items():
        contexts = context_dict["context_string"][:topk]
        prompt = create_yes_no_question(contexts)
        questions[f_id] = prompt
        print(prompt)
    return questions

def create_description_question(context_strings):
    prompt = f""
    for context_string in context_strings:
        prompt += " ".join(context_string) + "\n"
    prompt += f"\n Describe the common pattern observed among these 4 contexts above.\n"
    return prompt

def create_dict_questions_desc(contexts_dictionary, yes_dict, topk=4):
    questions = {}
    for f_id, context_dict in contexts_dictionary.items():
        if yes_dict[f_id]: 
            contexts = context_dict["context_string"][:topk]
            prompt = create_description_question(contexts)
            questions[f_id] = prompt # only store the ones that the LLM originally identified.
        else:
            questions[f_id] = None # if the LLM did not identify a common pattern, then we use this as extra information
    return questions


def extract_feature_summaries(description_responses):
    feature_summaries = {}
    pattern = r"The common pattern.*?(?:is|are)[\s'\"]*(.*?)(?:[.]|$)"
    for f_id, sentence in description_responses.items():
        match = re.search(pattern, sentence, re.IGNORECASE)
        if match:
            common_pattern = match.group(1)
            feature_summaries[f_id] = common_pattern
        else:
            feature_summaries[f_id] = None
    return feature_summaries

def get_random_context(fid, random_contexts):
    other_fids = list(random_contexts.keys())
    random_int = random.randint(0, len(other_fids)-1)
    while other_fids[random_int] == fid:
        random_int = random.randint(0, len(other_fids)-1)
    other_fid = other_fids[random_int]
    return random_contexts[other_fid]["context_string"][random.randint(0, len(random_contexts[other_fid]["context_string"])-1)]

def create_identification_experiment_questions(random_contexts, topk=4):
    questions = {}
    for f_id, context_dict in random_contexts.items():
        contexts = context_dict["context_string"][:topk].copy()
        random_context = get_random_context(f_id, random_contexts)
        contexts.append(random_context)
        random.shuffle(contexts)
        prompt = ""
        for idx, context in enumerate(contexts):
            prompt += f"Context {idx}: " + " ".join(context) + "\n"
        
        prompt += f"\nWhich context is different from the other contexts? Please reply with only the context number. \n"
        questions[f_id] = {"prompt": prompt, "truth": random_context, "contexts": contexts}
        print(prompt)
    return questions

def identification_test(rand_identification_prompts, pipeline):
    responses = {}
    n_yes = 0
    for f_id, question in rand_identification_prompts.items():
        prompt = question["prompt"]
        contexts = question["contexts"]
        answer = question["truth"]
        
    return responses, n_yes


def restore_dict(data_dict):
    for key, value in data_dict.items():
        if isinstance(value, dict):
            data_dict[key] = restore_dict(value)
        elif isinstance(value, list):
            new_list = []
            for item in value:
                if isinstance(item, list):
                    if all(isinstance(x, float) for x in item):
                        new_list.append(torch.tensor(item, dtype=torch.float32))
                    elif all(isinstance(x, int) for x in item):
                        new_list.append(torch.tensor(item, dtype=torch.int64))
                    else:
                        new_list.append(item)
                else:
                    new_list.append(item)
            data_dict[key] = new_list
        elif isinstance(value, (float, int)):
            data_dict[key] = torch.tensor([value], dtype=torch.float32 if isinstance(value, float) else torch.int64)
    return data_dict

def load_dict_contexts_fast(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"fast_dctxt_bs_{batch_size}_nb_{n_batches}.pkl")
    with open(dir_path, "rb") as file:
        dictionary_contexts = pickle.load(file)
    return restore_dict(dictionary_contexts)


def load_baseline_contexts_fast(dataset, batch_size, n_batches, baseline):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "baseline_contexts")
    dir_path = os.path.join(dir, f"fast_bctxt_bs_{batch_size}_nb_{n_batches}_{baseline}.pkl")
    with open(dir_path, "rb") as file:
        baseline_contexts = pickle.load(file)
    return restore_dict(baseline_contexts)

def filter_contexts(contexts, min_f_act=1, min_contexts=4): # filter out contexts that have less than min_f_act and min_contexts
    filtered_contexts = {}
    for f_id, context in contexts.items():
        if torch.tensor(context["max_score"]).mean() > min_f_act and len(context["context_string"]) > min_contexts:
            filtered_contexts[f_id] = context
    return filtered_contexts


def reduce_baseline(contexts_dictionary):
    for fid, context_dict in contexts_dictionary.items():
        for i in range(len(context_dict["context_string"])):
            context = context_dict["context_string"][i]
            f_acts = context_dict["context_f_acts"][i]
            tokens = context_dict["context_tokens"][i]
            print(f_acts > 0 )
            # get nonzero indices
            values, indices = torch.sort(f_acts, descending=True)
            topk_indices = indices[:5] # top 5
            # sort those in ascending order to maintain order
            topk_indices = topk_indices.sort()[0]
            new_context_strings = []
            new_context_tokens = []
            new_f_acts = []
            for idx in topk_indices:
                new_context_strings.append(context[idx])
                new_context_tokens.append(tokens[idx])
                new_f_acts.append(f_acts[idx])
            context_dict["context_string"][i] = new_context_strings
            context_dict["context_tokens"][i] = new_context_tokens
            context_dict["context_f_acts"][i] = new_f_acts
            print(context_dict["context_string"][i])
    return contexts_dictionary  

if __name__ == "__main__":
    # model_id = "aaditya/OpenBioLLM-Llama3-8B"
    baseline = get_baseline()
    topk = get_topk() # topk contexts to consider
    use_reduced = True # since we probably won't use main context for a bit.
    dataset = "mimiciii_clean"
    if baseline == "L1":
        contexts_dictionary = load_dict_contexts_fast(dataset=dataset, batch_size=64, n_batches=None)
    elif baseline == "RANDOM":
        contexts_dictionary = load_baseline_contexts_fast(dataset=dataset, batch_size=64, n_batches=None, baseline="RANDOM")
    elif baseline == "RELU":   
        contexts_dictionary = load_baseline_contexts_fast(dataset=dataset, batch_size=16, n_batches=None, baseline="RELU_CLEAN")
    elif baseline == "L1_REDUCED":
        contexts_dictionary = load_baseline_contexts_fast(dataset=dataset, batch_size=64, n_batches=None, baseline="L1_REDUCED")
    
    if use_reduced:
         # take top 5 tokens instead for each context, and use that instead.
        if baseline != "L1" and baseline != "L1_REDUCED":
            contexts_dictionary = reduce_baseline(contexts_dictionary)

    print("SUCCESS IN LOADING CONTEXTS!")
    df = create_questions_df(contexts_dictionary, topk=topk)
    df = df.dropna(axis=0, how='any')
    df.to_csv(f"experiments/dict_att/mimiciii_clean/dictionary/questions/all_filtered_{baseline}_questions_red{use_reduced}.csv", index=False)
    # sample the df to get our selection. 
    sampled_df = df.sample(n=100, random_state=42, replace=False)
    sampled_df.to_csv(f"experiments/dict_att/mimiciii_clean/dictionary/questions/sample_filtered_{baseline}_questions_red{use_reduced}.csv", index=False)