
import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json
from interpret import experiment
import optuna
from optuna.integration import PyTorchLightningPruningCallback
from torch.optim import Adam
from torchmetrics import Accuracy, F1Score
from functools import partial
import lightning.pytorch as pl
import einops
from cli import freeze_plm_icd, get_dataset, get_gpu, use_pretrained_dict, get_finetune_batchsize, use_finetuned_weights, get_experiment, load_chkpt, test, get_classifier, get_lr, get_type
from train import ensure_directory_exists
from dict_att import DictionaryAutoEncoder, DicAttnModule, SparsePLMICD, SPINEAutoEncoder
from data import get_original_datasets, print_gpu_memory_usage, print_memory_usage, get_n_classes
from lightning.pytorch.callbacks import EarlyStopping, LearningRateMonitor
from lightning.pytorch.loggers import TensorBoardLogger
from lightning.pytorch.callbacks import ModelCheckpoint
from train import load_plm_icd
from train import PLMICD
from train_dict import get_hyperparameters, save_hyperparameters, load_dictionary, get_dictionary_paths
from src.data.transform import Transform
# for generation of dictionary label embeddings using dictionary
import nltk 
import re
import einops
from einops import rearrange
nltk.download('punkt')  # For tokenization
nltk.download('stopwords')  # For stop words
from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from interpret.utils import convert_to_str
from data import get_transforms
import pandas as pd 
from pyhealth.medcode import InnerMap
def no_whitespace(word):
    return re.sub(r"\s+", "", word)

# load ICD code descriptions

def inverse_transform_from_indices(indices : torch.Tensor, label_transform):
    return [label_transform.index2target[int(i)] for i in indices]

def load_ICD9_explanations(path="/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/figs/data/ICD9_descriptions"):
    df = pd.read_csv(path, delimiter='\t')
    df.set_index('@', inplace=True)
    return df

def convert_str_to_indices(str_tokens, text_transform : Transform):
    return text_transform.tokenizer.batch_transform(str_tokens) 


def create_ICD_dictionary(n_classes, label_transform, text_transform, df):
    stop_words = set(stopwords.words('english'))
    ICD9_idx_to_desc = {}
    nMissing = 0
    icd9proc = InnerMap.load("ICD9PROC")
    for i in range(n_classes):
        key = inverse_transform_from_indices(torch.tensor([i]), label_transform)[0]
        if key in df.index:
            ICD9_description = df.loc[key]['ICD9 Hierarchy Root']
            filtered_desc_tokens = [no_whitespace(word.lower()) for word in word_tokenize(ICD9_description) if not word in stop_words]
            # we need to tokenize the description
            filtered_desc_tokens = [token for token in filtered_desc_tokens if re.search(r'[a-zA-Z]', token)]
            if i % 1000 == 0:
                print(key)
                print(filtered_desc_tokens)
            filtered_desc_tokens = [text_transform.tokenizer.encode(token)[1:-1] for token in filtered_desc_tokens] 
            filtered_desc_tokens = [item for sublist in filtered_desc_tokens for item in sublist]
            # print("Reconverted:", convert_to_str(filtered_desc_tokens, text_transform))
            ICD9_idx_to_desc[i] = filtered_desc_tokens
        else:
            ICD9_idx_to_desc[i] = text_transform.tokenizer.encode("None")[1:-1]
            nMissing+=1

    print("# Missing ICD9 codes:", nMissing)
    return ICD9_idx_to_desc


def convert_to_dictionary_embeddings(ICD9_idx_to_desc, plm_icd : PLMICD, dictionary : DictionaryAutoEncoder, device):
    # convert the descriptions to embeddings
    ICD9_desc_to_emb = {}
    for i in range (len(ICD9_idx_to_desc.keys())):
        tokens = torch.tensor([ICD9_idx_to_desc[i]]).to(device)
        # print(plm_icd.parameters()[0].device)
        b,l = tokens.shape
        ICD9_desc_to_emb[i] = plm_icd.get_hidden_output(tokens.view(1,1,-1))
        ICD9_desc_to_emb[i] = dictionary.encode(ICD9_desc_to_emb[i])
        ICD9_desc_to_emb[i] = rearrange(ICD9_desc_to_emb[i], "b l c f -> (b l c) f").cpu().detach()
    return ICD9_desc_to_emb

# to aggregate teh embeddings into a matrix
def aggregate(icd_emb_dict, type="none"):
    aggregated_vectors = []
    for i in range(len(icd_emb_dict.keys())):
        if type == "max":
            aggregated_vectors.append(torch.max(icd_emb_dict[i], dim=0).values.unsqueeze(0))
        elif type == "mean":
            aggregated_vectors.append(torch.mean(icd_emb_dict[i], dim=0).unsqueeze(0))
        else:
            aggregated_vectors.append(icd_emb_dict[i])
    return torch.cat(aggregated_vectors, dim=0)
        # icd_emb_dict[i] = torch.mean(icd_emb_dict[i], dim=0)



d_mlp = 768
gpu = get_gpu()
dataset = get_dataset()
n_classes = get_n_classes(dataset)
use_finetuned_model = use_finetuned_weights()
dictionary_trained = use_pretrained_dict()
dictionary_type = get_type()
print(f"d_mlp: {d_mlp}")
print(f"gpu: {gpu}")
print(f"dataset: {dataset}")
print(f"n_classes: {n_classes}")
print(f"use_finetuned_model: {use_finetuned_model}")
print(f"dictionary_trained: {dictionary_trained}")
print(f"dictionary_type: {dictionary_type}")

device = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")
experiment_directory = os.path.join("experiments", "dict_att", dataset)
alpha = 8 # we just stick with 8 for now
dictionary, params = load_dictionary(dataset, dictionary_type, alpha, use_finetuned_model)
dictioanry = dictionary.to(device) # ??? lol I literaly don't know why this doesn't look into device already.
label_directory = os.path.join("experiments", "dict_att", dataset, "label_embeddings")
ensure_directory_exists(label_directory)

plm_path="RoBERTa-base-PM-M3-Voc-hf"
plm_icd = load_plm_icd(plm_path, dataset, n_classes, device, use_finetuned_model)
df = load_ICD9_explanations()
text_transform, label_transform = get_transforms(dataset)
print("Processing CODES!")
icd_dict = create_ICD_dictionary(n_classes, label_transform, text_transform, df)
icd_sparse_emb = convert_to_dictionary_embeddings(icd_dict, plm_icd, dictionary, device)
aggregated_icd_sparse_emb_mean = aggregate(icd_sparse_emb, type="mean")
print("Aggregated ICD Sparse Emb Mean:", aggregated_icd_sparse_emb_mean.mean())
print("Aggregated ICD Sparse Emb Mean Max:", aggregated_icd_sparse_emb_mean.max())
print("Aggregated ICD Emb min:", aggregated_icd_sparse_emb_mean.min())
aggregated_icd_sparse_emb_max = aggregate(icd_sparse_emb, type="max")
print("Aggregated ICD Sparse Emb Max Mean:", aggregated_icd_sparse_emb_max.mean())
print("Aggregated ICD Sparse Emb Max Max:", aggregated_icd_sparse_emb_max.max())
print("Aggregated ICD Emb min:", aggregated_icd_sparse_emb_max.min())

torch.save(aggregated_icd_sparse_emb_mean, os.path.join(label_directory, f"alpha_{alpha}_{dictionary_type}_ft_{use_finetuned_model}_icd_emb_mean.pt"))
torch.save(aggregated_icd_sparse_emb_max, os.path.join(label_directory, f"alpha_{alpha}_{dictionary_type}_ft_{use_finetuned_model}_icd_emb_max.pt"))
print("Save Success!")