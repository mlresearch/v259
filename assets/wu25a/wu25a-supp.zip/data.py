# DONT OVERLOOK THIS IF YOURE ACTUALLY INTERESTED IN A REPRODUCTION
# Please see here for the src libraries, that you'll have to put these files in. 
# https://github.com/JoakimEdin/medical-coding-reproducibility
# ^^^^^^^^, The repo above has all the additional code files that you'll need to run this code. 
# I didn't think it made sense literally sharing an entire other repo, so I just shared the main files that I 
# think should be enough to reproduce this work.

import torch 
import pandas as pd 
import numpy as np 
import dask.array as da
import dask.dataframe as dd
import psutil
import pytorch_lightning as pl
import pickle
import os
from torch.utils.data import Dataset, DataLoader
from omegaconf import OmegaConf
from src.data.data_pipeline import data_pipeline
from src.factories import (
    get_callbacks,
    get_dataloaders,
    get_datasets,
    get_lookups,
    get_lr_scheduler,
    get_metric_collections,
    get_model,
    get_optimizer,
    get_text_encoder,
    get_transform,
)
from rich.pretty import pprint

def get_mimic3_clean_cfg(batch_size = 8) -> OmegaConf:
    cfg = {'seed': 1337, 'deterministic': False, 'gpu': 5, 'name': None, 'debug': False, 'load_model': './files/model_checkpoints/mimiciii_clean/plm-icd', 'data': {'dir': 'files/data/mimiciii_clean', 'data_filename': 'mimiciii_clean.feather', 'split_filename': 'mimiciii_clean_splits.feather', 'code_column_names': ['icd9_diag', 'icd9_proc'], 'max_length': 4000}, 'dataset': {'name': 'HuggingfaceDataset', 'configs': {'chunk_size': 128}}, 'dataloader': {'max_batch_size':batch_size, 'batch_size': batch_size, 'num_workers': 2, 'drop_last': True, 'pin_memory': False, 'batch_sampler': {'name': 'BySequenceLengthSampler', 'configs': {'bucket_boundaries': [400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2600, 3000, 4000]}}}, 'model': {'name': 'PLMICD', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf'}}, 'text_encoder': {}, 'trainer': {'epochs': 20, 'validate_on_training_data': True, 'print_metrics': False, 'use_amp': True, 'threshold_tuning': True}, 'optimizer': {'name': 'AdamW', 'configs': {'lr': 5e-05, 'weight_decay': 0}}, 'lr_scheduler': {'name': 'linear', 'configs': {'num_warmup_steps': 2000}}, 'label_transform': {'name': 'OneHotEncoder', 'configs': {}}, 'text_transform': {'name': 'HuggingFaceTokenizer', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf', 'add_special_token': True, 'padding': False, 'use_fast': True, 'do_lower_case': True, 'max_length': None, 'truncation': False}}, 'metrics': [{'name': 'F1Score', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'F1Score', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'ExactMatchRatio', 'configs': {'threshold': 0.5}}, {'name': 'Precision_K', 'configs': {'k': 5}}, {'name': 'Precision_K', 'configs': {'k': 8}}, {'name': 'Precision_K', 'configs': {'k': 15}}, {'name': 'Recall_K', 'configs': {'k': 10}}, {'name': 'Recall_K', 'configs': {'k': 15}}, {'name': 'MeanAveragePrecision', 'configs': {}}, {'name': 'PrecisionAtRecall', 'configs': {}}, {'name': 'AUC', 'configs': {'average': 'micro'}}, {'name': 'AUC', 'configs': {'average': 'macro'}}, {'name': 'LossMetric', 'configs': {}}], 'lookup': {'code_description': {'code_desc_path': None, 'code_column': None, 'desc_column': None}}, 'callbacks': [{'name': 'WandbCallback', 'configs': {'project': 'automatic-medical-coding', 'entity': None, 'dir': '/data/je'}}, {'name': 'SaveBestModelCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map'}}, {'name': 'EarlyStoppingCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map', 'patience': 6}}], 'data.max_length': 4000}
    cfg = OmegaConf.create(cfg)
    return cfg

def get_mimiciv_icd9_cfg(batch_size=8) -> OmegaConf:
    cfg = {'seed': 1337, 'deterministic': False, 'gpu': 7, 'name': None, 'debug': False, 'load_model': './files/model_checkpoints/mimiciv_icd9/plm-icd', 'data': {'dir': 'files/data/mimiciv_icd9', 'data_filename': 'mimiciv_icd9.feather', 'split_filename': 'mimiciv_icd9_split.feather', 'code_column_names': ['icd9_diag', 'icd9_proc'], 'max_length': 4000}, 'dataset': {'name': 'HuggingfaceDataset', 'configs': {'chunk_size': 128}}, 'dataloader': {'max_batch_size': batch_size, 'batch_size': batch_size, 'num_workers': 2, 'drop_last': True, 'pin_memory': False, 'batch_sampler': {'name': 'BySequenceLengthSampler', 'configs': {'bucket_boundaries': [400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2600, 3000, 4000]}}}, 'model': {'name': 'PLMICD', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf'}}, 'text_encoder': {}, 'trainer': {'epochs': 20, 'validate_on_training_data': True, 'print_metrics': False, 'use_amp': True, 'threshold_tuning': True}, 'optimizer': {'name': 'AdamW', 'configs': {'lr': 5e-05, 'weight_decay': 0}}, 'lr_scheduler': {'name': 'linear', 'configs': {'num_warmup_steps': 2000}}, 'label_transform': {'name': 'OneHotEncoder', 'configs': {}}, 'text_transform': {'name': 'HuggingFaceTokenizer', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf', 'add_special_token': True, 'padding': False, 'use_fast': True, 'do_lower_case': True, 'max_length': None, 'truncation': False}}, 'metrics': [{'name': 'F1Score', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'F1Score', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'ExactMatchRatio', 'configs': {'threshold': 0.5}}, {'name': 'Precision_K', 'configs': {'k': 5}}, {'name': 'Precision_K', 'configs': {'k': 8}}, {'name': 'Precision_K', 'configs': {'k': 15}}, {'name': 'Recall_K', 'configs': {'k': 10}}, {'name': 'Recall_K', 'configs': {'k': 15}}, {'name': 'MeanAveragePrecision', 'configs': {}}, {'name': 'PrecisionAtRecall', 'configs': {}}, {'name': 'AUC', 'configs': {'average': 'micro'}}, {'name': 'AUC', 'configs': {'average': 'macro'}}, {'name': 'LossMetric', 'configs': {}}], 'lookup': {'code_description': {'code_desc_path': None, 'code_column': None, 'desc_column': None}}, 'callbacks': [{'name': 'WandbCallback', 'configs': {'project': 'automatic-medical-coding', 'entity': None, 'dir': '/data/je'}}, {'name': 'SaveBestModelCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map'}}, {'name': 'EarlyStoppingCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map', 'patience': 6}}], 'data.max_length': 4000}
    cfg = OmegaConf.create(cfg)
    return cfg

def  get_mimiciv_icd10_cfg(batch_size =8) -> OmegaConf:
    cfg = {'seed': 1337, 'deterministic': False, 'gpu': 7, 'name': None, 'debug': False, 'load_model': './files/model_checkpoints/mimiciv_icd10/plm-icd', 'data': {'dir': 'files/data/mimiciv_icd10', 'data_filename': 'mimiciv_icd10.feather', 'split_filename': 'mimiciv_icd10_split.feather', 'code_column_names': ['icd10_diag', 'icd10_proc'], 'max_length': 4000}, 'dataset': {'name': 'HuggingfaceDataset', 'configs': {'chunk_size': 128}}, 'dataloader': {'max_batch_size': batch_size, 'batch_size': batch_size, 'num_workers': 2, 'drop_last': True, 'pin_memory': False, 'batch_sampler': {'name': 'BySequenceLengthSampler', 'configs': {'bucket_boundaries': [400, 600, 800, 1000, 1200, 1400, 1600, 1800, 2000, 2200, 2600, 3000, 4000]}}}, 'model': {'name': 'PLMICD', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf'}}, 'text_encoder': {}, 'trainer': {'epochs': 20, 'validate_on_training_data': True, 'print_metrics': False, 'use_amp': True, 'threshold_tuning': True}, 'optimizer': {'name': 'AdamW', 'configs': {'lr': 5e-05, 'weight_decay': 0}}, 'lr_scheduler': {'name': 'linear', 'configs': {'num_warmup_steps': 2000}}, 'label_transform': {'name': 'OneHotEncoder', 'configs': {}}, 'text_transform': {'name': 'HuggingFaceTokenizer', 'configs': {'model_path': '/home/user/MIMIC_DictionaryLearning/medical-coding-reproducibility/RoBERTa-base-PM-M3-Voc-hf', 'add_special_token': True, 'padding': False, 'use_fast': True, 'do_lower_case': True, 'max_length': None, 'truncation': False}}, 'metrics': [{'name': 'F1Score', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'F1Score', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Recall', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'Precision', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'micro', 'threshold': 0.5}}, {'name': 'FPR', 'configs': {'average': 'macro', 'threshold': 0.5}}, {'name': 'ExactMatchRatio', 'configs': {'threshold': 0.5}}, {'name': 'Precision_K', 'configs': {'k': 5}}, {'name': 'Precision_K', 'configs': {'k': 8}}, {'name': 'Precision_K', 'configs': {'k': 15}}, {'name': 'Recall_K', 'configs': {'k': 10}}, {'name': 'Recall_K', 'configs': {'k': 15}}, {'name': 'MeanAveragePrecision', 'configs': {}}, {'name': 'PrecisionAtRecall', 'configs': {}}, {'name': 'AUC', 'configs': {'average': 'micro'}}, {'name': 'AUC', 'configs': {'average': 'macro'}}, {'name': 'LossMetric', 'configs': {}}], 'lookup': {'code_description': {'code_desc_path': None, 'code_column': None, 'desc_column': None}}, 'callbacks': [{'name': 'WandbCallback', 'configs': {'project': 'automatic-medical-coding', 'entity': None, 'dir': '/data/je'}}, {'name': 'SaveBestModelCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map'}}, {'name': 'EarlyStoppingCallback', 'configs': {'split': 'val', 'target': 'all', 'metric': 'map', 'patience': 6}}], 'data.max_length': 4000}
    cfg = OmegaConf.create(cfg)
    return cfg

def get_n_classes(dataset):
    n_classes = {"mimiciii_clean" : 3681, "mimiciv_icd9": 6150, "mimiciv_icd10" : 7942}
    if dataset not in n_classes.keys():
        raise ValueError("Dataset not supported")
    return n_classes[dataset]

class HiddenActivation(Dataset):

    def __init__(self, tokens, hidden_activations):
        self.tokens = tokens 
        self.hidden_activations = hidden_activations
        

    def __len__(self):
        return self.tokens.shape[0]
    
    # return (tensor, tensor)
    def __getitem__(self, index):
        token = self.tokens[index]
        hidden_activation = self.hidden_activations[index]
        return int(token), torch.from_numpy(hidden_activation)

def get_interpret_objs(dataset="mimiciii_clean", batch_size=8):
    cfg = None
    if dataset == "mimiciii_clean":
        cfg = get_mimic3_clean_cfg(batch_size)
    elif dataset == "mimiciv_icd9":
        cfg = get_mimiciv_icd9_cfg(batch_size)
    elif dataset == "mimiciv_icd10":
        cfg = get_mimiciv_icd10_cfg(batch_size)
    else:
        raise ValueError("Dataset not supported")
    
    # Option 2: Load configuration from a YAML file
    data = data_pipeline(config=cfg.data)

    text_encoder = get_text_encoder(
        config=cfg.text_encoder, data_dir=cfg.data.dir, texts=data.get_train_documents
    )
    label_transform = get_transform(
        config=cfg.label_transform,
        targets=data.all_targets,
        load_transform_path=cfg.load_model,
    )
    text_transform = get_transform(
        config=cfg.text_transform,
        texts=data.get_train_documents,
        text_encoder=text_encoder,
        load_transform_path=cfg.load_model,
    )
    data.truncate_text(cfg.data.max_length)
    data.transform_text(text_transform.batch_transform)

    lookups = get_lookups(
        config=cfg.lookup,
        data=data,
        label_transform=label_transform,
        text_transform=text_transform,
    )

    # print data info ~ overrides
    pprint(lookups.data_info)
    datasets = get_datasets(
        config=cfg.dataset,
        data=data,
        text_transform=text_transform,
        label_transform=label_transform,
        lookups=lookups,
    )

    dataloaders = get_dataloaders(config=cfg.dataloader, datasets_dict=datasets)

    # test 
    # test needs to be of the original dataset
    test_loader = dataloaders['test']
    test_loader.num_workers = 4
    return test_loader, text_encoder, label_transform, text_transform


def get_label_transform(dataset="mimiciii_clean"):
    cfg = None
    if dataset == "mimiciii_clean":
        cfg = get_mimic3_clean_cfg()
    elif dataset == "mimiciv_icd9":
        cfg = get_mimiciv_icd9_cfg()
    elif dataset == "mimiciv_icd10":
        cfg = get_mimiciv_icd10_cfg()
    else:
        raise ValueError("Dataset not supported")
    
    # Option 2: Load configuration from a YAML file
    data = data_pipeline(config=cfg.data)
    
    label_transform = get_transform(
        config=cfg.label_transform,
        targets=data.all_targets,
        load_transform_path=cfg.load_model,
    )
    return label_transform



def get_transforms(dataset="mimiciii_clean"):
    cfg = None
    if dataset == "mimiciii_clean":
        cfg = get_mimic3_clean_cfg()
    elif dataset == "mimiciv_icd9":
        cfg = get_mimiciv_icd9_cfg()
    elif dataset == "mimiciv_icd10":
        cfg = get_mimiciv_icd10_cfg()
    else:
        raise ValueError("Dataset not supported")
    
    # Option 2: Load configuration from a YAML file
    data = data_pipeline(config=cfg.data)
    text_encoder = get_text_encoder(
        config=cfg.text_encoder, data_dir=cfg.data.dir, texts=data.get_train_documents
    )
    text_transform = get_transform(
        config=cfg.text_transform,
        texts=data.get_train_documents,
        text_encoder=text_encoder,
        load_transform_path=cfg.load_model,
    )

    label_transform = get_transform(
        config=cfg.label_transform,
        targets=data.all_targets,
        load_transform_path=cfg.load_model,
    )
    return text_transform, label_transform


def get_original_datasets(dataset="mimiciii_clean", batch_size=16):
    cfg = None
    if dataset == "mimiciii_clean":
        cfg = get_mimic3_clean_cfg(batch_size)
    elif dataset == "mimiciv_icd9":
        cfg = get_mimiciv_icd9_cfg(batch_size)
    elif dataset == "mimiciv_icd10":
        cfg = get_mimiciv_icd10_cfg(batch_size)
    else:
        raise ValueError("Dataset not supported")
    
    data = data_pipeline(config=cfg.data)

    text_encoder = get_text_encoder(
        config=cfg.text_encoder, data_dir=cfg.data.dir, texts=data.get_train_documents
    )
    label_transform = get_transform(
        config=cfg.label_transform,
        targets=data.all_targets,
        load_transform_path=cfg.load_model,
    )
    text_transform = get_transform(
        config=cfg.text_transform,
        texts=data.get_train_documents,
        text_encoder=text_encoder,
        load_transform_path=cfg.load_model,
    )
    data.truncate_text(cfg.data.max_length)
    data.transform_text(text_transform.batch_transform)

    lookups = get_lookups(
        config=cfg.lookup,
        data=data,
        label_transform=label_transform,
        text_transform=text_transform,
    )

    # print data info ~ overrides
    pprint(lookups.data_info)
    datasets = get_datasets(
        config=cfg.dataset,
        data=data,
        text_transform=text_transform,
        label_transform=label_transform,
        lookups=lookups,
    )

    dataloaders = get_dataloaders(config=cfg.dataloader, datasets_dict=datasets)
    train_loader = dataloaders["train"]
    train_loader.num_workers = 4
    # val
    val_loader = dataloaders["val"]
    val_loader.num_workers = 4
    # validation set needs to be of the original dataset


    # test 
    # test needs to be of the original dataset
    test_loader = dataloaders['test']
    test_loader.num_workers = 4
    return train_loader, val_loader, test_loader


def print_gpu_memory_usage(device_index=0, label=""):
    """
    Prints the GPU memory usage for a specific GPU device.
    
    Args:
        device_index (int): The index of the GPU device to check. Default is 0.
        label (str): An optional label to print with the memory usage.
    """
    with torch.cuda.device(device_index):
        print(label)
        print(f"GPU {device_index} Memory Usage:")
        allocated = torch.cuda.memory_allocated() / (1024 ** 3)
        cached = torch.cuda.memory_cached() / (1024 ** 3)
        print(f"Allocated: {allocated:.3f} GB")
        print(f"Cached: {cached:.3f} GB")


def print_memory_usage(label=""):
    memory_info = psutil.Process().memory_info()
    print(label)
    print(f"Memory used: {memory_info.rss / (1024 * 1024)} MB")
    return memory_info.rss / (1024 * 1024)



class LitDictionaryData(pl.LightningDataModule):
  def __init__(self, dataset : str,  train_dataset, val_loader, test_loader, aenc_batch_size=64, num_workers=4):
      super(LitDictionaryData, self).__init__()
      self.dataset = dataset
      self.train_dataset = train_dataset
      self.val_loader = val_loader
      self.test_loader = test_loader
      self.aenc_batch_size = aenc_batch_size
      self.num_workers = num_workers

  def train_dataloader(self):
    return DataLoader(self.train_dataset, batch_size=self.aenc_batch_size, shuffle=True, num_workers=self.num_workers)

  def val_dataloader(self):
    return self.val_loader
  
  def test_dataloader(self):
    return self.test_loader

class LitDictionaryDataMemoryEfficient(pl.LightningDataModule):
    def __init__(self, train_loader, val_loader, test_loader):
        super(LitDictionaryDataMemoryEfficient, self).__init__()
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.test_loader = test_loader
    def train_dataloader(self):
        return self.train_loader
    def val_dataloader(self):
        return self.val_loader
    def test_dataloader(self):
        return self.test_loader

if __name__ == "__main__":

    train, val, test = get_original_datasets("mimiciv_icd10")
    print(len(train))
    print(len(val))
    print(len(test))
    train, val, test = get_original_datasets("mimiciv_icd9")
    print(len(train))
    print(len(val))
    print(len(test))