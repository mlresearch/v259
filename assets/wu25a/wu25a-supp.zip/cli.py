import sys


def get_topk():
    if '-topk' in sys.argv:
        return int(sys.argv[sys.argv.index('-topk') + 1])
    return 4

def get_seed():
    if '-seed' in sys.argv:
        return int(sys.argv[sys.argv.index('-seed') + 1])
    return 1337

def get_n_batches():
    if '-n_batches' in sys.argv:
        return int(sys.argv[sys.argv.index('-n_batches') + 1])
    return None

def get_run_id():
    if '-run_id' in sys.argv:
        return int(sys.argv[sys.argv.index('-run_id') + 1])
    raise ValueError("Run ID not specified")

def get_alpha():
    if '-alpha' in sys.argv:
        return int(sys.argv[sys.argv.index('-alpha') + 1])
    return 8

def use_ddp():
    if '-ddp' in sys.argv:
        return True
    return False

def use_scheduler():
    if '-scheduler' in sys.argv:
        return True
    return False

def freeze_dictionary():
    if '-freeze_dict' in sys.argv:
        return True
    return False

def use_optuna():
    return '-optuna' in sys.argv

def get_epochs():
    if '-epochs' in sys.argv:
        return int(sys.argv[sys.argv.index('-epochs') + 1])
    return 20

def test():
    if '-test' in sys.argv:
        return True
    return False

def freeze_plm_icd():
    if '-freeze_plm_icd' in sys.argv:
        return True
    return False

def get_classifier():
    if '-classifier' in sys.argv:
        return str(sys.argv[sys.argv.index('-classifier') + 1])
    return "simple"

def get_finetune_batchsize():
    if '-ft_batchsize' in sys.argv:
        return int(sys.argv[sys.argv.index('-ft_batchsize') + 1])
    return 8

def use_finetuned_weights():
    if '-use_ft_wts' in sys.argv:
        return True
    return False

def get_experiment():
    if '-experiment' in sys.argv:
        return str(sys.argv[sys.argv.index('-experiment') + 1])
    assert ValueError("Experiment not specified")

def get_dataset():
    if '-dataset' in sys.argv:
        return str(sys.argv[sys.argv.index('-dataset') + 1])
    return None

def use_pretrained_dict():
    if '-pretrained_dict' in sys.argv:
        return True
    return False

def get_gpu():
    if '-gpu' in sys.argv:
        return int(sys.argv[sys.argv.index('-gpu') + 1])
    return -1

def get_type():
    if '-type' in sys.argv:
        return str(sys.argv[sys.argv.index('-type') + 1])
    return "L1"

def tune():
    if '-tune' in sys.argv:
        return True
    return False

def use_reconstruction_loss():
    if '-guided' in sys.argv:
        return True
    return False

def hyperparameter_search():
    if '-search' in sys.argv:
        return True
    return False
    
def get_experiment():
    if '-experiment' in sys.argv:
        return str(sys.argv[sys.argv.index('-experiment') + 1])
    return "Please_Insert_Experiment_Name_With-experiment"

def load_chkpt():
    if '-load' in sys.argv:
        return str(sys.argv[sys.argv.index('-load') + 1])
    return None

def get_l1_coefficient():
    if '-l1' in sys.argv:
        return float(sys.argv[sys.argv.index('-l1') + 1])
    return 0.0

def get_lr():
    if '-lr' in sys.argv:
        return float(sys.argv[sys.argv.index('-lr') + 1])
    return 0.0001

def get_baseline():
    if '-baseline' in sys.argv:
        return str(sys.argv[sys.argv.index('-baseline') + 1])
    return 'PCA'
# def get_gpu():
#     if '-gpu' in sys.argv:
#         return int(sys.argv[sys.argv.index('-gpu') + 1])
#     return -1

def get_pretrain_step_procedure():
    if '-pretrain' in sys.argv:
        return str(sys.argv[sys.argv.index('-pretrain') + 1])
    return None
