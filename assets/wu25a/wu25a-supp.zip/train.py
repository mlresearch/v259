import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json
import optuna
import pprint
import torch.nn.init as init
from optuna.integration import PyTorchLightningPruningCallback
from torchmetrics import Accuracy, F1Score
from functools import partial
from lightning.pytorch.loggers import NeptuneLogger
import lightning.pytorch as pl
from einops import rearrange
from cli import *
from data import get_original_datasets, print_gpu_memory_usage, print_memory_usage, get_n_classes
from lightning.pytorch.loggers import TensorBoardLogger
from lightning.pytorch.callbacks import ModelCheckpoint
from train_dict import  save_hyperparameters, load_dictionary, get_dictionary_paths
import numpy as np 
import random 

# limitations under the License.
"""PyTorch RoBERTa model. """
from transformers import RobertaModel, AutoConfig
def init_weights(m):
    if isinstance(m, nn.Linear):
        init.kaiming_uniform_(m.weight, nonlinearity='relu')


from torch.nn.init import xavier_uniform_

def ensure_directory_exists(directory_path):
    """
    Checks if the specified directory exists, and creates it if it doesn't.

    Args:
        directory_path (str): The path of the directory to check and create.

    Returns:
        None
    """
    try:
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            print(f"Directory '{directory_path}' created successfully.")
        else:
            print(f"Directory '{directory_path}' already exists.")
    except OSError as e:
        print(f"Failed to create directory '{directory_path}'.")
        raise e

def set_seed(seed):
    """Set the random number generation seed globally for `torch`, `numpy` and `random`"""
    os.environ["PYTHONHASHSEED"] = str(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    random.seed(seed)
    # LOGGER.info("Set 'numpy', 'random' and 'torch' random seed to %s", seed)

class LabelAttention(nn.Module):
    def __init__(self, input_size: int, projection_size: int, num_classes: int):
        super().__init__()
        self.first_linear = nn.Linear(input_size, projection_size, bias=False)
        self.second_linear = nn.Linear(projection_size, num_classes, bias=False)
        self.third_linear = nn.Linear(input_size, num_classes)
        self.attn = None
        self._init_weights(mean=0.0, std=0.03)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """LAAT attention mechanism

        Args:
            x (torch.Tensor): [batch_size, seq_len, input_size]

        Returns:
            torch.Tensor: [batch_size, num_classes]
        """
        weights = torch.tanh(self.first_linear(x))
        att_weights = self.second_linear(weights)
        att_weights = torch.nn.functional.softmax(att_weights, dim=1).transpose(1, 2)
        weighted_output = att_weights @ x
        self.attn = att_weights
        return (
            self.third_linear.weight.mul(weighted_output)
            .sum(dim=2)
            .add(self.third_linear.bias)
        )
    
    def get_Z(self, x):
        weights = torch.tanh(self.first_linear(x))
        return weights 

    def _init_weights(self, mean: float = 0.0, std: float = 0.03) -> None:
        """
        Initialise the weights

        Args:
            mean (float, optional): Mean of the normal distribution. Defaults to 0.0.
            std (float, optional): Standard deviation of the normal distribution. Defaults to 0.03.
        """

        torch.nn.init.normal_(self.first_linear.weight, mean, std)
        torch.nn.init.normal_(self.second_linear.weight, mean, std)
        torch.nn.init.normal_(self.third_linear.weight, mean, std)

# num_classes: 3681 for MIMIC_III_CLean
# MIMICIV ICD 9 
# MIMICIV ICD 10
class PLMICD(nn.Module):
    def __init__(self, num_classes: int, model_path: str, **kwargs):
        super().__init__()

        self.num_classes = num_classes
        self.model_path = model_path
        self.config = AutoConfig.from_pretrained(
            model_path, num_labels=num_classes, finetuning_task=None
        )
        self.roberta = RobertaModel(
            self.config, add_pooling_layer=False
        ).from_pretrained(model_path, config=self.config)
        self.attention = LabelAttention(
            input_size=self.config.hidden_size,
            projection_size=self.config.hidden_size,
            num_classes=num_classes,
        )
        self.hidden_size = self.config.hidden_size
        self.loss = torch.nn.functional.binary_cross_entropy_with_logits

    def get_loss(self, logits, targets):
        return self.loss(logits, targets)

    def training_step(self, batch) -> dict[str, torch.Tensor]:
        data, targets, attention_mask = batch.data, batch.targets, batch.attention_mask
        logits = self(data, attention_mask)
        loss = self.get_loss(logits, targets)
        logits = torch.sigmoid(logits)
        return {"logits": logits, "loss": loss, "targets": targets}

    def validation_step(self, batch) -> dict[str, torch.Tensor]:
        data, targets, attention_mask = batch.data, batch.targets, batch.attention_mask
        logits = self(data, attention_mask)
        loss = self.get_loss(logits, targets)
        logits = torch.sigmoid(logits)
        return {"logits": logits, "loss": loss, "targets": targets}

    def forward(
        self,
        input_ids=None,
        attention_mask=None,
    ):
        r"""
        input_ids (torch.LongTensor of shape (batch_size, num_chunks, chunk_size))
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size, num_labels)`, `optional`):
        """

        batch_size, num_chunks, chunk_size = input_ids.size()
        outputs = self.roberta(
            input_ids.view(-1, chunk_size),
            attention_mask=attention_mask.view(-1, chunk_size)
            if attention_mask is not None
            else None,
            return_dict=False,
        )

        hidden_output = outputs[0].view(batch_size, num_chunks * chunk_size, -1)
        logits = self.attention(hidden_output)
        return logits

    def get_hidden_output(
        self,
        input_ids=None,
        attention_mask=None,
    ):
        r"""
        input_ids (torch.LongTensor of shape (batch_size, num_chunks, chunk_size))
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size, num_labels)`, `optional`):
        """

        batch_size, num_chunks, chunk_size = input_ids.size()
        outputs = self.roberta(
            input_ids.view(-1, chunk_size),
            attention_mask=attention_mask.view(-1, chunk_size)
            if attention_mask is not None
            else None,
            return_dict=False,
        )

        hidden_output = outputs[0].view(batch_size, num_chunks, chunk_size, -1)
        return hidden_output.detach()
    
    def get_Z(self, input_ids=None, attention_mask=None):
        hidden_output = self.get_hidden_output(input_ids, attention_mask)
        return self.attention.get_Z(hidden_output)
    
    def get_reconstructed_logits(self, reconstructed_hidden_outputs):
        logits = self.attention(reconstructed_hidden_outputs).detach()
        return logits

def load_plm_icd(plm_path, dataset, n_classes, device, use_finetuned=False) -> PLMICD: 
    lm = PLMICD(n_classes, plm_path).to(device)
    if use_finetuned:
        lm.load_state_dict(torch.load(f"files/model_checkpoints/{dataset}/plm-icd/best_model.pt", map_location=device)["model"])
    return lm

class DictionaryAutoEncoder(nn.Module):
    def __init__(self, d_mlp, d_hidden, l1_coeff, l2_coeff,  dtype=torch.float16):
        super(DictionaryAutoEncoder, self).__init__()

        # self.W_enc = nn.Parameter(torch.empty(d_mlp, d_hidden))
        # self.W_dec = nn.Parameter(torch.empty(d_hidden, d_mlp))
        # self.b_enc = nn.Parameter(torch.zeros(d_hidden))
        # self.b_dec = nn.Parameter(torch.zeros(d_mlp)), equivalent to the below.

        self.encoder = nn.Linear(d_mlp, d_hidden)
        self.decoder = nn.Linear(d_hidden, d_mlp)
        self.dict_size = d_hidden
        self.apply(init_weights)  # Initialize weights with Kaiming uniform and convert to float16

        self.d_mlp = d_mlp
        self.dict_size = d_hidden
        self.d_hidden = d_hidden
        self.l1_coeff = l1_coeff
        self.l2_coeff = l2_coeff

    def encode(self, x):
        return F.relu(self.encoder(x))

    def decode(self, f):
        return self.decoder(f)

    def forward(self, x, denoising=False, std = None):
        noise = 0
        if denoising:
            noise = torch.normal(0, std, size=x.size()).to(x.device)

        acts = self.encode(x + noise)
        x_reconstruct = self.decode(acts)

        recon_loss = (x_reconstruct - x).pow(2).sum(-1).mean(0)
        l1_loss = self.l1_coeff * acts.abs().sum().mean(0)
        l2_loss = self.l2_coeff * acts.square().sum().mean(0) # average over the batch
        loss = recon_loss + l1_loss + l2_loss # reconstruction + elastic net loss regularizationt erms
        loss = {"loss" : loss,
                "l1_loss" : l1_loss,
                "l2_loss" : l2_loss,
                "recon_loss" : recon_loss}
        
        return acts, x_reconstruct, loss

    def get_dictionary_value(self, id):
        return self.decoder.weight.T[id]
    
    def get_dictionary_matrix(self):
        return self.decoder.weight.T


# Two heads, a dictionary attention head and a label attention head
class DictionaryLabelAttention(nn.Module):
    #  ICD memory should be 1 x c x f in size, save in a torch tensor
    def __init__(self,dictionary : DictionaryAutoEncoder, input_size : int, dictionary_size, projection_size: int, num_classes: int, path_to_icd_memory : str, debug=False):
        super().__init__()

        self.dictionary = dictionary 
        self.dictionary_size = dictionary_size
        self.projection_size = projection_size 
        self.path_to_icd_memory = path_to_icd_memory
        self.icd_memory = nn.Parameter(torch.zeros(1, num_classes, dictionary_size))
        self.attn = None
        if not debug:
            icd_memory = torch.load(path_to_icd_memory)
            icd_memory = icd_memory.unsqueeze(0)
            self.icd_memory = nn.Parameter(icd_memory)
        else:
            self.icd_memory = nn.Parameter(torch.zeros(1, num_classes, dictionary_size))
        self.third_linear = nn.Linear(input_size, num_classes)

    def compute_dictionary_attention(self, x):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1) # should be b x s x f
        attention = f @ self.icd_memory.transpose(1,2).to(f.device) # b x s x f * 1 x f x c -> b x s x c 
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    def compute_modified_dictionary_attention(self, x, addition_mask=None, multiply_mask= None):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1) # should be b x s x f
        modified_icd_memory = self.icd_memory.data.clone()
        if multiply_mask is not None:
            modified_icd_memory *= multiply_mask
        if addition_mask is not None:
            modified_icd_memory += addition_mask
        attention = f @ modified_icd_memory.transpose(1,2).to(f.device) # b x s x f * 1 x f x c -> b x s x c 
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    def compute_dictionary_attention_ablated(self, x, f_ablate, icd_idx, use_precise=True):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1)
       
        # iteratively go through each batch with a different icd_matrix effectively
        icd_matrices = []
        if use_precise:
            # Create a mask tensor for zeroing out the intersecting weights
            mask = torch.ones_like(self.icd_memory.transpose(1, 2))
            mask[:, f_ablate, icd_idx] = 0
            
            # Apply the mask to the icd_memory tensor
            icd_matrices = self.icd_memory.transpose(1, 2).to(f.device) * mask
        else:
            # Create a mask tensor for zeroing out the class memory vector
            mask = torch.ones_like(self.icd_memory.transpose(1, 2))
            mask[:, :, icd_idx] = 0
            
            # Apply the mask to the icd_memory tensor
            icd_matrices = self.icd_memory.transpose(1, 2).to(f.device) * mask

        attention = f @ icd_matrices
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    # f_ablate are the indices of dictionary features we want to remove for the specific ICD code
    def forward_ablated(self, x, f_ablate, icd_idx, use_precise=True):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_dictionary_attention_ablated(x, f_ablate, icd_idx, use_precise)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict


    def forward_modified(self, x, addition_mask=None, multiply_mask= None):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_modified_dictionary_attention(x, addition_mask, multiply_mask)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        self.attn = combined_attn
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict


    def forward(self, x):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_dictionary_attention(x)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        self.attn = combined_attn
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict
        # get attention weights with dictionary attention

def objective(trial : optuna.trial.Trial, 
              n_classes, 
              train_loader, 
              val_loader, 
              gpu,
              experiment_directory,
              dataset,
              classifier_head_type,
              dictionary,
              dictionary_size,
              plm):


    # get logger
    hidden_size = 768 # this is hardcoded for now, but you should get this from the plm.
    projection_size = trial.suggest_int("projection_size", 768, dictionary_size) # project to a lower dimension?
    lr = trial.suggest_loguniform("lr", 1e-6, 1e-1) # learning rate
    recon_lambda = trial.suggest_loguniform("recon_lambda", 1e-6, 0.01) # reconstruction loss lambda
    logs_dir = os.path.join(experiment_directory, "logs", classifier_head_type)
    ensure_directory_exists(logs_dir)
    filename = f"{classifier_head_type}_dict_att_lr_{lr}_projection_size_{projection_size}"
    logger = TensorBoardLogger(save_dir=logs_dir,
                               name=filename)
    
    print(f"Trial Started Using Hyperparameters: projection_size: {projection_size}, lr: {lr}, recon_lambda: {recon_lambda}")
    checkpoint_callback = ModelCheckpoint(
        dirpath=os.path.join(experiment_directory, "chkpts"),
        filename= filename + "_t" +str(trial.number),
        save_top_k=1,  # Save all checkpoints
        monitor='val_f1_macro',
        mode='max'
    )
    # Create an instance of the module with the desired classifier head type
    model = SparsePLMICDClassifierModule(plm= plm,
                                        classifier_head_type=classifier_head_type, 
                                        dictionary=dictionary, 
                                        dictionary_size = dictionary_size, 
                                        projection_size = projection_size,
                                        hidden_size= hidden_size, 
                                        num_classes = int(n_classes),
                                        dataset= dataset, 
                                        lr= lr,
                                        recon_lambda = recon_lambda)


    # Create a PyTorch Lightning Trainer, validate very 0.99
    trainer = pl.Trainer(logger=logger,
                         max_epochs=3, 
                         val_check_interval=0.99, 
                         devices=[gpu],
                         callbacks=[checkpoint_callback,
                             PyTorchLightningPruningCallback(trial, monitor="val_macro_f1")])

    # Train the model
    trainer.fit(model, train_loader, val_loader)
    
    # Retrieve the validation macro F1 score from the callback_metrics
    val_micro_f1 = trainer.callback_metrics["val_micro_f1"].item()
    return val_micro_f1





def micro_f1_score(y_pred, y_true, num_classes=3681, threshold=0.5):
    """
    Compute the macro F1 score for multi-label classification.
    
    Args:
        y_pred (torch.Tensor): Predicted probabilities or scores of shape (batch_size, num_classes).
        y_true (torch.Tensor): True labels of shape (batch_size, num_classes).
        num_classes (int): Number of classes.
        threshold (float): Threshold value for converting probabilities to binary predictions.
    
    Returns:
        float: Macro F1 score.
    """
    y_pred = (y_pred > threshold).float()
    
    true_positives = torch.sum(y_pred * y_true)
    predicted_positives = torch.sum(y_pred)
    actual_positives = torch.sum(y_true)
    precision = true_positives / (predicted_positives + 1e-7)
    recall = true_positives / (actual_positives + 1e-7)
    f1_scores = 2 * (precision * recall) / (precision + recall + 1e-7)
    
    return f1_scores.item()


class SparsePLMICDClassifierModule(pl.LightningModule):
    def __init__(self, plm, 
                 classifier_head_type, 
                 dictionary, 
                 dictionary_size,
                 projection_size, 
                 hidden_size, 
                 num_classes, 
                 dataset, 
                 lr, 
                 recon_lambda,
                 freeze_plm=False,
                 freeze_dictionary=False,
                 use_scheduler= False,
                 path_to_icd_memory: str = None):
        super().__init__()
        self.plm = plm
        self.classifier_head_type = classifier_head_type
        self.dictionary = dictionary
        self.dataset = dataset
        self.lr = lr
        self.recon_lambda = recon_lambda
        self.warmup_steps = 2000
        self.use_scheduler = use_scheduler
        if freeze_dictionary:
            for param in self.dictionary.parameters():
                param.requires_grad_ = False

    
        self.classifier_head = DictionaryLabelAttention(self.dictionary, hidden_size, dictionary_size, projection_size, num_classes, path_to_icd_memory)
        
        self.loss_fn = nn.BCEWithLogitsLoss()
        self.micro_f1 = F1Score(num_labels=num_classes, average='micro', task="multilabel")
        self.macro_f1 = F1Score(num_labels=num_classes, average='macro', task="multilabel")
        if freeze_plm:
            for param in self.plm.parameters():
                param.requires_grad_ = False
        self.val_outputs = {"labels" : [], "predictions" : []}
        self.test_outputs = {"labels" : [], "predictions" : []}

    def forward(self, input_ids, attention_mask=None):
        batch_size, num_chunks, chunk_size = input_ids.size()
        outputs = self.plm(
            input_ids.view(-1, chunk_size),
            attention_mask=attention_mask.view(-1, chunk_size)
            if attention_mask is not None
            else None,
            return_dict=False,
        )
        
        hidden_output = outputs[0].view(batch_size, num_chunks * chunk_size, -1)
        # reshape back into batch size
        logits, aenc_loss_dict = self.classifier_head(hidden_output)
        # maybe add a false negative loss term later
        return logits, aenc_loss_dict
    
    def training_step(self, batch, batch_idx):
        input_ids, labels, attention_mask = batch.data, batch.targets, batch.attention_mask
        logits, aenc_loss_dict = self(input_ids, attention_mask)
        loss = self.loss_fn(logits, labels)
        if self.use_scheduler:
            self.lr_schedulers().step()
            current_lr = self.trainer.lr_scheduler_configs[0].scheduler.get_last_lr()[0]
            self.log("lr", current_lr, prog_bar=True, logger=True)
            
        self.log("classification_loss", loss.item(), prog_bar=True)
        loss += self.recon_lambda * aenc_loss_dict["loss"]
        self.log("train_loss", loss, prog_bar=True)
        self.log("my_micro_f1", micro_f1_score(torch.sigmoid(logits), labels), prog_bar=True)
        self.log("aenc_loss:", aenc_loss_dict["loss"].item(), prog_bar=True)
        return loss
    
    def validation_step(self, batch, batch_idx):
        input_ids, labels, attention_mask = batch.data, batch.targets, batch.attention_mask
        logits, aenc_loss_dict = self(input_ids, attention_mask)
        loss = self.loss_fn(logits, labels).item()
        
        self.log("val_loss", loss)
        self.log("val_aenc_loss", aenc_loss_dict["loss"].item())  
        self.val_outputs["labels"].append(labels)
        self.val_outputs["predictions"].append(torch.sigmoid(logits).cpu().detach())
        return loss
    
    def test_step(self, batch, batch_idx):
        input_ids, labels, attention_mask = batch.data, batch.targets, batch.attention_mask
        logits, _ = self(input_ids, attention_mask)
        self.test_outputs["labels"].append(labels)
        self.test_outputs["predictions"].append(torch.sigmoid(logits).cpu().detach())
        
    def on_validation_epoch_end(self):
        from pyhealth.metrics import multilabel_metrics_fn
        y_true = torch.cat(self.val_outputs["labels"], dim=0).cpu().numpy()
        y_prob = torch.cat(self.val_outputs["predictions"], dim=0).cpu().numpy()
        metrics = multilabel_metrics_fn(y_true, y_prob, metrics=["accuracy", "f1_macro", "f1_micro", "f1_weighted"], threshold=0.3)
        for key, val in metrics.items():
            self.log(f"val_{key}", val, prog_bar=True)
        self.val_outputs = {"labels" : [], "predictions" : []}
    
    def on_test_epoch_end(self):
        from pyhealth.metrics import multilabel_metrics_fn
        y_true = torch.cat(self.test_outputs["labels"], dim=0).cpu().numpy()
        y_prob = torch.cat(self.test_outputs["predictions"], dim=0).cpu().numpy()
        metrics = multilabel_metrics_fn(y_true, y_prob, metrics=["accuracy", "f1_macro", "f1_micro", "f1_weighted"], threshold=0.3)
        for key, val in metrics.items():
            self.log(f"test_{key}", val, prog_bar=True)
        self.test_outputs = {"labels" : [], "predictions" : []}

    def configure_optimizers(self):
        optimizer = torch.optim.AdamW(self.parameters(), lr=self.lr)
        def warmup_lambda(current_step):
            if current_step < self.warmup_steps:
                return float(current_step) / float(max(1, self.warmup_steps))
            return 1.0

        warmup_scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, warmup_lambda)
        schedulers = [
            {
                'scheduler': warmup_scheduler,
                'interval': 'step',
                'frequency': 1,
            }
            # {
            #     'scheduler': cosine_scheduler,
            #     'interval': 'step',
            #     'frequency': 1,
            # },
        ]

        return [optimizer], schedulers
    
    def get_hidden_output(
        self,
        input_ids=None,
        attention_mask=None,
    ):
        r"""
        input_ids (torch.LongTensor of shape (batch_size, num_chunks, chunk_size))
        labels (:obj:`torch.LongTensor` of shape :obj:`(batch_size, num_labels)`, `optional`):
        """

        batch_size, num_chunks, chunk_size = input_ids.size()
        outputs = self.plm(
            input_ids.view(-1, chunk_size),
            attention_mask=attention_mask.view(-1, chunk_size)
            if attention_mask is not None
            else None,
            return_dict=False,
        )

        hidden_output = outputs[0].view(batch_size, num_chunks, chunk_size, -1)
        return hidden_output.detach()
    
    def get_reconstructed_logits(self, reconstructed_hidden_outputs):
        logits, _ = self.classifier_head(reconstructed_hidden_outputs)
        return logits
    
    def get_ablated_f_probs(self, reconstructed_hidden_outputs, f_ablate, icd_idx, use_precise=True):
        logits, _ = self.classifier_head.forward_ablated(reconstructed_hidden_outputs, f_ablate, icd_idx, use_precise)
        return logits
    
    def get_modified_forward(self, reconstructed_hidden_outputs, addition_mask = None, multiply_mask = None):
        logits, _ = self.classifier_head.forward_modified(reconstructed_hidden_outputs, addition_mask, multiply_mask)
        return logits


if __name__ == "__main__":
    # get command line arguments
    gpu = get_gpu()
    dataset = get_dataset()
    n_classes = get_n_classes(dataset)
    print("n_classes:", n_classes, "type:", type(n_classes))
    classifier_head_type = get_classifier()
    print("TRAINING WITH:", classifier_head_type)
    use_finetuned_model = use_finetuned_weights()
    dictionary_trained = use_pretrained_dict()
    finetune_batchsize = get_finetune_batchsize()
    hyperparameter_tune = use_optuna()
    dictionary_type = get_type()
    num_epochs = get_epochs()
    freeze_plm = freeze_plm_icd()
    freeze_dict = freeze_dictionary()
    use_lr_scheduler = use_scheduler()
    alpha = get_alpha() # manually set alpha
    run_id = get_run_id() 
    seed = get_seed()
    set_seed(seed)

    variables = {
        "run_id": run_id,
        "alpha": alpha,
        "gpu": gpu,
        "dataset": dataset, 
        "n_classes": n_classes,
        "n_classes_type": type(n_classes),
        "classifier_head_type": classifier_head_type,
        "use_finetuned_model": use_finetuned_model,
        "dictionary_trained": dictionary_trained,
        "finetune_batchsize": finetune_batchsize,
        "hyperparameter_tune": hyperparameter_tune,
        "dictionary_type": dictionary_type,
        "num_epochs": num_epochs,
        "freeze_plm": freeze_plm,
        "freeze_dictionary": freeze_dict,
        "use_scheduler": use_lr_scheduler,
        "seed": seed
    }
    pprint.pprint(variables)

    plm_path="RoBERTa-base-PM-M3-Voc-hf"
    experiment_directory = os.path.join("experiments", "dict_att", dataset)
    classifier_directory = os.path.join(experiment_directory, classifier_head_type)
    ensure_directory_exists(experiment_directory)
    ensure_directory_exists(os.path.join(experiment_directory, "chkpts"))
    if gpu < 0:
        print("Using CPU!")
        device = torch.device("cpu")
    else:
        device = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")
    plm_icd = load_plm_icd(plm_path, dataset,  n_classes, device, use_finetuned_model)
    plm = plm_icd.roberta

    dictionary_hyperparameters = None 
    d_mlp = 768
    if dictionary_trained: # load dictionary 
        dictionary, dictionary_hyperparameters = load_dictionary(dataset, dictionary_type, alpha, use_finetuned_model)
    else: # use a vanilla untrained
        print("Using Random Dictionary!")
        dictionary_hyperparameters = {"alpha" : alpha}
        dictionary_size = dictionary_hyperparameters["alpha"] * d_mlp
        if dictionary_type == "SPINE":
            dictionary_hyperparameters["asl"] = 1
            dictionary_hyperparameters["psl"] = 1
            dictionary = SPINEAutoEncoder(d_mlp=d_mlp, d_hidden=dictionary_size, asl_coeff=dictionary_hyperparameters["asl"], psl_coeff=dictionary_hyperparameters["psl"])
        else:
            dictionary_hyperparameters["l1_coeff"] = 1e-3
            dictionary_hyperparameters["l2_coeff"] = 0
            dictionary = DictionaryAutoEncoder(d_mlp=d_mlp, d_hidden=dictionary_size, l1_coeff=dictionary_hyperparameters["l1_coeff"], l2_coeff=dictionary_hyperparameters["l2_coeff"])

    # note you'll have to load the datasets yourselves and set them up using the github repo: https://github.com/JoakimEdin/medical-coding-reproducibility
    train_loader, val_loader, test_loader = get_original_datasets(dataset, batch_size=finetune_batchsize)
    dictionary_size = dictionary_hyperparameters["alpha"] * d_mlp
    print("Dictionary Size:", dictionary_size)

    best_hyperparameters = {}
    if hyperparameter_tune:
        pruner = optuna.pruners.MedianPruner() 
        study = optuna.create_study(direction="maximize", pruner=pruner)
        objective = partial(objective, 
                        n_classes = n_classes, 
                        train_loader = train_loader, 
                        val_loader = val_loader, 
                        gpu = gpu,
                        experiment_directory = experiment_directory,
                        dataset = dataset,
                        classifier_head_type = classifier_head_type,
                        dictionary = dictionary,
                        dictionary_size = dictionary_size,
                        plm = plm)

        # 20 quick trains
        study.optimize(objective, 20) # 10 different hyperparameters to try out

        # get the best hyperparameters and train again.
        print("Best trial:")
        trial = study.best_trial
        best_hyperparameters = study.best_trial.params
        print("Best hyperparameters:", best_hyperparameters)
        print("Saving trials hyperparameter to dataframe.")
        df = study.trials_dataframe()
        trials_dataframe = os.path.join(experiment_directory, "chkpts", f"{classifier_head_type}_trials.csv")
        df.to_csv(trials_dataframe, index=False)
    else: # TUNE here for fast runs
        if classifier_head_type == "lda":
            best_hyperparameters = {
                "projection_size": 768,
                "lr": get_lr(),
                "recon_lambda": 1e-6,
                "epochs": num_epochs
            }
        elif classifier_head_type == "dictionary_classifier":
            best_hyperparameters = {
                "projection_size": 768,
                "lr": get_lr(),
                "recon_lambda": 1e-6,
                "epochs": num_epochs
            }
        elif classifier_head_type == "simple":
            best_hyperparameters = {
                'projection_size': 768, 'lr': 3.60212553275904e-05, 'recon_lambda': 2.692159868424216e-06, 'epochs': num_epochs
            }
        elif classifier_head_type == "la":
            best_hyperparameters = {
                "projection_size": 768,
                "lr": get_lr(),
                "recon_lambda": 1e-6,
                "epochs": num_epochs
            }
        else:
            best_hyperparameters = {
                "projection_size": 768,
                "lr": get_lr(),
                "recon_lambda": 1e-6,
                "epochs": num_epochs
            }

    for key, val in dictionary_hyperparameters.items():
        best_hyperparameters[f"dict:{key}"] = val

    projection_size = best_hyperparameters["projection_size"] # 
    lr = best_hyperparameters["lr"]
    print("Using learning rate:", lr)
    recon_lambda = best_hyperparameters["recon_lambda"]

    # save hyperparameters
    print("Saving hyperparameters:", best_hyperparameters)
    final_model_hyperparameters_path = os.path.join(experiment_directory, "chkpts", f"final_{classifier_head_type}_hyperparameters_E{num_epochs}.json")
    save_hyperparameters(hyperparameters= best_hyperparameters, path=final_model_hyperparameters_path)


    if freeze_plm:
        print("Freezing PLM Weights!")

    label_directory = os.path.join("experiments", "dict_att", dataset, "label_embeddings")
    label_emb_path = os.path.join(label_directory, f"alpha_{alpha}_{dictionary_type}_ft_{use_finetuned_model}_icd_emb_mean.pt")

    # Create a PyTorch Lightning Trainer, validate very 0.99
    model = SparsePLMICDClassifierModule(plm= plm,
                                            classifier_head_type=classifier_head_type, 
                                            dictionary=dictionary, 
                                            dictionary_size = dictionary_size, 
                                            projection_size= projection_size, 
                                            hidden_size=768,
                                            num_classes = n_classes,
                                            dataset= dataset, 
                                            lr= lr,
                                            recon_lambda=recon_lambda,
                                            freeze_plm = freeze_plm,
                                            freeze_dictionary = freeze_dict,
                                            use_scheduler= use_lr_scheduler,
                                            path_to_icd_memory= label_emb_path)



    logs_dir = os.path.join(experiment_directory, "logs", classifier_head_type)
    ensure_directory_exists(logs_dir)   

    tags = ["training"]
    for key, value in variables.items():
        print(key, ":", value)
        if type(value) is bool: 
            if value:
                tags.append(key)
        elif type(value) is int:
            tags.append(f"{key}_{value}")
        elif type(value) is str:
            tags.append(value)


    neptune_logger = logger
    neptune_logger.log_hyperparams(best_hyperparameters)

    filename = f"{classifier_head_type}_dict_att_lr_{lr}_hidden_size_{projection_size}_rl{recon_lambda}_E{num_epochs}_ft{use_finetuned_model}_freeze{freeze_plm}"
        # logger = TensorBoardLogger(save_dir=logs_dir,
    #                             name=filename)
    chkpt_dir = os.path.join(experiment_directory, "chkpts", classifier_head_type)
    ensure_directory_exists(chkpt_dir)

    checkpoint_callback = ModelCheckpoint(
            dirpath=chkpt_dir,
            filename=filename,
            save_top_k=1,  # Save all checkpoints
            monitor='val_f1_micro',
            mode='max'
        )

    trainer = pl.Trainer(logger=neptune_logger,
                        max_epochs=num_epochs, 
                        val_check_interval=0.99, 
                        devices=[gpu],
                        callbacks=[checkpoint_callback])
    
    if use_ddp():
        trainer = pl.Trainer(logger=neptune_logger,
                            strategy='ddp',
                            max_epochs=num_epochs, 
                            val_check_interval=0.99, 
                            accelerator='gpu',
                            devices=1,
                            callbacks=[checkpoint_callback])

    # train the initial model
    model_name = f"{classifier_head_type}_dict_{dictionary_type}_att_lr_{lr}_hidden_size_{projection_size}_rl{recon_lambda}_E{num_epochs}_ft{use_finetuned_model}_freeze_{freeze_plm}_R{run_id}.ckpt"
    trainer.fit(model, train_loader, val_loader)
    trainer.save_checkpoint(os.path.join(chkpt_dir, model_name))

    # Test the final model
    trainer.test(model, test_loader)


    # save best lightning module

    


    # checkpoint_callback = ModelCheckpoint(
    #             dirpath=f'experiments/{dataset}/chkpts',
    #             filename='{epoch}-{val_loss:.2f}-{val_micro_f1:.2f}-{val_macro_f1:.2f}-' + classifier_head_type,
    #             save_top_k=3,
    #             monitor='val_macro_f1',
    #             mode='min',
    #             period=1,
    #             save_last=True,
    #         )
