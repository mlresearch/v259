import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json
import pickle
from optuna.integration import PyTorchLightningPruningCallback
from torch.optim import Adam
from torchmetrics import Accuracy, F1Score
from functools import partial
import lightning.pytorch as pl
from cli import freeze_plm_icd, get_dataset, get_gpu, get_n_batches, use_pretrained_dict, get_finetune_batchsize, use_finetuned_weights, get_experiment, load_chkpt, test, get_classifier, use_optuna, get_epochs, get_type, get_lr, freeze_dictionary, use_scheduler, use_ddp, get_baseline
from train import ensure_directory_exists
from data import get_original_datasets, print_gpu_memory_usage, print_memory_usage, get_n_classes, get_interpret_objs
from train import load_plm_icd
from train import PLMICD
from train_dict import get_hyperparameters, save_hyperparameters, load_dictionary, get_dictionary_paths
from pyhealth.metrics import multilabel_metrics_fn
from train import SparsePLMICDClassifierModule
from autoencoders.learned_dict import IdentityReLU, RandomDict

def filter_baseline_dictionaries(dictionary):
    for fid, context_dict in dictionary.items():
        for i in range(len(context_dict["context_string"])):
            context = context_dict["context_string"][i]
            if len(context) > 13:
                midpt = len(context) // 2
                begin = midpt - 6
                end = midpt + 6
                context_dict["context_tokens"][i] = context_dict["context_tokens"][i][begin:end] 
                context_dict["context_string"][i] = context_dict["context_string"][i][begin:end]
                context_dict["context_f_acts"][i] = context_dict["context_f_acts"][i][begin:end]
    return dictionary

def filter_L1_dictionaries(dictionary):
    # iterate through each fid, process them such that we only take in the nonzero tokens
    for fid, context_dict in dictionary.items():
        for i in range(len(context_dict["context_string"])):
            context = context_dict["context_string"][i]
            f_acts = context_dict["context_f_acts"][i]
            tokens = context_dict["context_tokens"][i]
            print(f_acts > 0 )
            # get nonzero indices
            nonzero_indices = torch.nonzero(f_acts > 0)
            print(nonzero_indices)
            new_context_strings = []
            new_context_tokens = []
            new_f_acts = []
            for idx in nonzero_indices:
                new_context_strings.append(context[idx])
                new_context_tokens.append(tokens[idx])
                new_f_acts.append(f_acts[idx])
            context_dict["context_string"][i] = new_context_strings
            context_dict["context_tokens"][i] = new_context_tokens
            context_dict["context_f_acts"][i] = new_f_acts
            print(context_dict["context_string"][i])

    return dictionary

def convert_dict(data_dict):
    for key, value in data_dict.items():
        if isinstance(value, dict):
            data_dict[key] = convert_dict(value)
        elif isinstance(value, list):
            new_list = []
            for item in value:
                if isinstance(item, torch.Tensor):
                    if item.dtype == torch.float32:
                        new_list.append(item.tolist())
                    else:
                        new_list.append(item.to(torch.int).tolist())
                else:
                    new_list.append(item)
            data_dict[key] = new_list
        elif isinstance(value, torch.Tensor):
            if value.dtype == torch.float32:
                data_dict[key] = value.tolist()
            else:
                data_dict[key] = value.to(torch.int).tolist()
    return data_dict

def load_dma_experiment(run_id, 
                        dataset,
                        dictionary_type,
                        device, 
                        projection_size = 768, 
                        lr = 5e-5, 
                        recon_lambda = 1e-6, 
                        alpha = 8,
                        use_finetuned_model = True,
                        classifier_head_type = "dma", 
                        freeze_plm=False,
                        freeze_dict=False,
                        use_lr_scheduler=True, 
                        num_epochs=20, 
                        d_mlp=768):
    n_classes = get_n_classes(dataset)
    experiments_directory = os.path.join("experiments", "dict_att", dataset)
    chkpts_directory = os.path.join(experiments_directory, "chkpts", classifier_head_type)
    plm_path = "RoBERTa-base-PM-M3-Voc-hf"
    chkpt_name = f"{classifier_head_type}_dict_{dictionary_type}_att_lr_{lr}_hidden_size_{projection_size}_rl{recon_lambda}_E{num_epochs}_ft{use_finetuned_model}_freeze_{freeze_plm}_R{run_id}.ckpt"
    chkpt_path = os.path.join(chkpts_directory, chkpt_name)
    plm_icd = load_plm_icd(plm_path, dataset,  n_classes, device, use_finetuned_model)
    plm = plm_icd.roberta
    label_directory = os.path.join("experiments", "dict_att", dataset, "label_embeddings")
    label_emb_path = os.path.join(label_directory, f"{dictionary_type}_ft_{use_finetuned_model}_icd_sparse_emb_mean.pt")

    dictionary, params = load_dictionary(dataset, dictionary_type="L1", alpha=alpha, finetuned_plm=use_finetuned_model)
    alpha = params["alpha"]
    dictionary_size = alpha * d_mlp
    model = SparsePLMICDClassifierModule.load_from_checkpoint(
        chkpt_path,
        plm=plm,
        classifier_head_type=classifier_head_type, 
        dictionary=dictionary, 
        dictionary_size = dictionary_size, 
        projection_size= projection_size, 
        hidden_size=d_mlp,
        num_classes = n_classes,
        dataset= dataset, 
        lr= lr,
        recon_lambda=recon_lambda,
        freeze_plm = freeze_plm,
        freeze_dictionary = freeze_dict,
        use_scheduler= use_lr_scheduler,
        path_to_icd_memory= label_emb_path
    )
    return model

import pandas as pd
import numpy as np
from src.data.transform import Transform
# want feature and all of its tokens displayed
SPACE = "·"
NEWLINE="↩"
TAB = "→"
def convert_to_str(tokens, text_transform : Transform):
    return [text_transform.tokenizer.batch_decode(token_chunk) for token_chunk in tokens]

def list_flatten(nested_list):
    return [x for y in nested_list for x in y]

def process_token(s):
    if isinstance(s, torch.Tensor):
        s = s.item()
    if isinstance(s, np.int64):
        s = s.item()
    s = s.replace(" ", SPACE)
    s = s.replace("\n", NEWLINE+"\n")
    s = s.replace("\t", TAB)
    return s

def process_tokens(tokens):
    return [process_token(s) for s in tokens]

def batchify(tokens):
    b,c,t = tokens.shape
    return tokens.reshape(b*c, t)

def make_token_df(tokens, text_transform : Transform, len_prefix=5, len_suffix=1):
    if len(tokens.shape) == 3:
        tokens = batchify(tokens)
    str_tokens = convert_to_str(tokens, text_transform)
    unique_token = tokens.view(-1).tolist()
    print(str_tokens)
    print(len(str_tokens))
    context = []
    batch = []
    pos = []
    label = []
    for b in range(tokens.shape[0]):
        # context.append([])
        # batch.append([])
        # pos.append([])
        # label.append([])
        for p in range(tokens.shape[1]):
            prefix = "".join(str_tokens[b][max(0, p-len_prefix):p])
            if p==tokens.shape[1]-1:
                suffix = ""
            else:
                suffix = "".join(str_tokens[b][p+1:min(tokens.shape[1]-1, p+1+len_suffix)])
            current = str_tokens[b][p]
            context.append(f"{prefix}|{current}|{suffix}")
            # print("CONTEXT:",context)
            batch.append(b)
            pos.append(p)
            label.append(f"{b}/{p}")

    return pd.DataFrame(dict(
        string=list_flatten(str_tokens),
        token_id=unique_token,
        context=context
    ))

# for processing tokens that are 
def make_token_df_lite(tokens, text_transform):
    if len(tokens.shape) == 3:
        tokens = batchify(tokens)
    # print(tokens.shape)
    # print(tokens)
    str_tokens = convert_to_str(tokens, text_transform)
    unique_token = tokens.view(-1).numpy()
    # print(str_tokens)
    # print(len(str_tokens))
    return pd.DataFrame(dict(
        str_tokens=list_flatten(str_tokens),
        token_id=unique_token
    ))

def make_feature_df(token_df, feature_acts, feature_id):
    token_df["feature_activation"] = feature_acts[:, feature_id].cpu().numpy()
    return token_df
import einops

def get_hidden_output(plm, input_ids, attention_mask):
    batch_size, num_chunks, chunk_size = input_ids.size()
    outputs = plm(
        input_ids.view(-1, chunk_size),
        attention_mask=attention_mask.view(-1, chunk_size)
        if attention_mask is not None
        else None,
        return_dict=False,
    )
    hidden_output = outputs[0].view(batch_size, num_chunks, chunk_size, -1)
    return hidden_output.detach()

# Use pre-existing dataloader to return a list of features
def get_feature_activations(batch, plm, dictionary, device):
    tokens, targets, attn_mask = batch.data, batch.targets, batch.attention_mask
    b,c,t = tokens.shape
    h_out = get_hidden_output(plm, tokens.to(device), attn_mask.to(device))
    h_out = einops.rearrange(h_out, "b c t d -> (b c t) d")
    feature_acts = dictionary.encode(h_out.to(device))
    tokens = einops.rearrange(tokens, "b c t -> (b c t)")
    return tokens.detach(), feature_acts.detach()
    
def highest_activated_feature(feature_acts):
    return torch.argmax(torch.max(feature_acts, dim=0).values)

def get_tokens_feature_acts(dataloader, plm_icd, dictionary, device, n_batches = None):
    all_f_acts = []
    all_tokens = []
    if n_batches == None:
        n_batches = len(dataloader)
    iterator = iter(dataloader)
    print(n_batches)
    i = 0
    while i < n_batches:  
        batch = next(iterator) 
        with torch.no_grad():
            tokens, feature_acts = get_feature_activations(batch, plm_icd, dictionary, device)
        all_tokens.append(tokens.cpu().detach())
        all_f_acts.append(feature_acts.cpu().detach())
        # print_gpu_memory_usage(i)
        i+=1 
    return torch.cat(all_tokens, dim=0), torch.cat(all_f_acts, dim=0)


def cluster_nonzero_chunks_parallel(tensor):
    # Find the indices of nonzero elements
    nonzero_indices = torch.nonzero(tensor.squeeze())
   
    # # Find the indices where the difference between consecutive nonzero indices is greater than 1
    chunk_boundaries = torch.where(nonzero_indices[1:] - nonzero_indices[:-1] > 1)[0] + 1

    # Split the nonzero indices into chunks
    chunks = torch.tensor_split(nonzero_indices.cpu(), chunk_boundaries.cpu())
    
    return list(chunks)

def get_top_contexts(f_id, feature_acts, tokens, text_transform, topk=10, context_len=4):    
    test_facts = feature_acts[:,f_id].squeeze()
    # chunk out consecutive nonzero activations for tokens
    chunks = cluster_nonzero_chunks_parallel(test_facts.squeeze())
    # get max activation for each chunk
    max_f_acts_per_chunk = []
    for chunk in chunks:
        # print(test_facts[chunk])
        max_f_acts_per_chunk.append(test_facts[chunk].max().item())

    # sort chunks by max activation
    chunk_max_scores, chunk_idxs = torch.tensor(max_f_acts_per_chunk).sort(descending=True)
    # for each chunk, get their context (tokens), and feature activations
    top_chunks_idxs = chunk_idxs[:topk]
    top_contexts = []
    top_context_strings = []
    top_context_f_acts = []
    top_max_scores = []
    for idx, chunk_idx in enumerate(top_chunks_idxs):
        chunk = chunks[chunk_idx]
        start_pos = chunk[0]
        end_pos = chunk[-1]

        context = tokens[start_pos-context_len:end_pos+context_len+1]
        context_string = convert_to_str(context.view(1,-1), text_transform)[0]
        context_f_acts = test_facts[start_pos - context_len:end_pos + context_len + 1]

        top_contexts.append(context)
        top_context_strings.append(context_string)
        top_context_f_acts.append(context_f_acts)
        top_max_scores.append(chunk_max_scores[idx])
        # break

    return {"context_tokens": top_contexts, "context_string": top_context_strings, "context_f_acts": top_context_f_acts, "max_score": top_max_scores}

def merge_contexts(current_contexts, next_contexts):
    for f_id, next_context in next_contexts.items():
        if f_id in current_contexts:
            current_context = current_contexts[f_id]
            current_context["context_tokens"] += next_context["context_tokens"]
            current_context["context_string"] += next_context["context_string"]
            current_context["context_f_acts"] += next_context["context_f_acts"]
            current_context["max_score"] += next_context["max_score"]
        else:
            current_contexts[f_id] = next_context
    return current_contexts

def compare_top_contexts(current_contexts, next_contexts, topk=10, context_len=4):
    current_contexts = merge_contexts(current_contexts, next_contexts)
    for f_id, curr_context in current_contexts.items():
        # sort by max_score of chunks
        chunk_max_scores, chunk_idxs = torch.tensor(curr_context["max_score"]).sort(descending=True)
        # if f_id == 47:
        #     print(chunk_max_scores)
        top_chunks_idxs = chunk_idxs[:topk]
        top_contexts = {}
        for key in curr_context.keys():
            top_contexts[key] = []
        for idx, chunk_idx in enumerate(top_chunks_idxs):
            for key in curr_context.keys():
                context_item = curr_context[key][chunk_idx.item()]
                top_contexts[key].append(context_item)

        current_contexts[f_id] = top_contexts  

    return current_contexts
    
    

def get_batch_dictionary_contexts(tokens, feature_acts, text_transform, topk=10, context_len=4):
    dictionary = {}
    nzero = torch.nonzero(feature_acts.max(dim=0).values)
    for f in nzero:
        f_id = f.item()
        dictionary[f_id] = get_top_contexts(f_id, feature_acts, tokens, text_transform, topk=topk, context_len=context_len)

    return dictionary

def get_all_dictionary_contexts_iterative(dataloader, model : SparsePLMICDClassifierModule, text_transform, n_batches, device, topk=10, context_len=4, buffer_size = 100):
    if n_batches == None:
        n_batches = len(dataloader)
    iterator = iter(dataloader)
    print(n_batches)
    i = 0
    curr_contexts = {}
    buffer_tokens = []
    buffer_feature_acts = []
    while i < n_batches:  
        batch = next(iterator) 
        with torch.no_grad():
            tokens, feature_acts = get_feature_activations(batch, model.plm, model.classifier_head.dictionary, device)
        buffer_tokens.append(tokens.detach().cpu())
        buffer_feature_acts.append(feature_acts.detach().cpu())
        if n_batches > buffer_size:
            if i % buffer_size == 0:
                buffer_tokens = torch.cat(buffer_tokens, dim=0)
                buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
                next_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
                if curr_contexts:
                    curr_contexts = compare_top_contexts(curr_contexts, next_contexts, topk=topk, context_len=context_len)
                else:
                    curr_contexts = next_contexts
                
                buffer_feature_acts = []
                buffer_tokens = []
        # print_gpu_memory_usage(i)
        i+=1 

    # basically, if the buffer is not full, we can just straight up create the contexts
    if n_batches < buffer_size:
        buffer_tokens = torch.cat(buffer_tokens, dim=0)
        buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
        curr_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
    elif len(buffer_tokens) > 0: # do one last compare
        buffer_tokens = torch.cat(buffer_tokens, dim=0)
        buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
        next_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
        curr_contexts = compare_top_contexts(curr_contexts, next_contexts, topk=topk, context_len=context_len) # this is leading ot issues?
        buffer_feature_acts = []
        buffer_tokens = []
    return curr_contexts

def get_all_dictionary_contexts(dataloader, model :SparsePLMICDClassifierModule, text_transform, n_batches, device):
    dictionary = {}
    tokens, feature_acts = get_tokens_feature_acts(dataloader, model.plm, model.classifier_head.dictionary, device, n_batches = n_batches)
    nzero = torch.nonzero(feature_acts.max(dim=0).values)
    for f in nzero:
        f_id = f.item()
        dictionary[f_id] = get_top_contexts(f_id, feature_acts, tokens, text_transform)

    return dictionary

def get_feature_activations_baseline(batch, model : PLMICD, dictionary, device):
    tokens, targets, attn_mask = batch.data, batch.targets, batch.attention_mask
    b,c,t = tokens.shape
    Z = model.get_Z(tokens.to(device), attn_mask.to(device))
    Z = einops.rearrange(Z, "b c t d -> (b c t) d")
    feature_acts = dictionary.encode(Z)
    tokens = einops.rearrange(tokens, "b c t -> (b c t)")
    return tokens.detach(), feature_acts.detach()

def get_all_dictionary_contexts_baseline(dataloader, model : PLMICD, dictionary, text_transform, n_batches, device, topk=10, context_len=4, buffer_size=100):
    if n_batches == None:
        n_batches = len(dataloader)
    iterator = iter(dataloader)
    print(n_batches)
    i = 0
    curr_contexts = {}
    buffer_tokens = []
    buffer_feature_acts = []
    while i < n_batches:  
        batch = next(iterator) 
        with torch.no_grad():
            tokens, feature_acts = get_feature_activations_baseline(batch, model, dictionary, device)
        buffer_tokens.append(tokens.detach().cpu())
        buffer_feature_acts.append(feature_acts.detach().cpu())
        ### There is a bug here, the buffer is not being emptied properly!!! :()
        if n_batches > buffer_size:
            if i % buffer_size == 0:
                buffer_tokens = torch.cat(buffer_tokens, dim=0)
                buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
                next_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
                if curr_contexts:
                    curr_contexts = compare_top_contexts(curr_contexts, next_contexts, topk=topk, context_len=context_len)
                else:
                    curr_contexts = next_contexts
                print_gpu_memory_usage(0, f"buffer_feature_acts:{buffer_feature_acts.shape}")
                buffer_feature_acts = []
                buffer_tokens = []
        # print_gpu_memory_usage(i)
        i+=1 

    # basically, if the buffer is not full, we can just straight up create the contexts
    if n_batches <= buffer_size:
        buffer_tokens = torch.cat(buffer_tokens, dim=0)
        buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
        curr_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
    elif len(buffer_tokens) > 0: # do one last compare if stuff is leftover
        buffer_tokens = torch.cat(buffer_tokens, dim=0)
        buffer_feature_acts = torch.cat(buffer_feature_acts, dim=0)
        next_contexts = get_batch_dictionary_contexts(buffer_tokens, buffer_feature_acts, text_transform, topk=topk, context_len=context_len)
        curr_contexts = compare_top_contexts(curr_contexts, next_contexts, topk=topk, context_len=context_len) # this is leading ot issues?
        buffer_feature_acts = []
        buffer_tokens = []
    return curr_contexts


def save_dictionary_contexts(dataset, dictionary_contexts, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"dctxt_bs_{batch_size}_nb_{n_batches}.pt")
    ensure_directory_exists(dir)
    torch.save(dictionary_contexts, dir_path)

def load_dictionary_contexts(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"dctxt_bs_{batch_size}_nb_{n_batches}.pt")
    return torch.load(dir_path)

def save_filtered_contexts(dataset, filtered_contexts, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "filtered_contexts")
    dir_path = os.path.join(dir, f"fdctxt_bs_{batch_size}_nb_{n_batches}.pt")
    ensure_directory_exists(dir)
    torch.save(filtered_contexts, dir_path)

def load_filtered_contexts(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "filtered_contexts")
    dir_path = os.path.join(dir, f"fdctxt_bs_{batch_size}_nb_{n_batches}.pt")
    return torch.load(dir_path)

def save_baseline_contexts(dataset, baseline_contexts, batch_size, n_batches, baseline):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "baseline_contexts")
    dir_path = os.path.join(dir, f"bdctxt_bs_{batch_size}_nb_{n_batches}_{baseline}.pt")
    ensure_directory_exists(dir)
    torch.save(baseline_contexts, dir_path)

def save_baseline_contexts_fast(dataset, baseline_contexts, batch_size, n_batches, baseline):
    baseline_contexts = convert_dict(baseline_contexts)
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "baseline_contexts")
    dir_path = os.path.join(dir, f"fast_bctxt_bs_{batch_size}_nb_{n_batches}_{baseline}.pkl")
    ensure_directory_exists(dir)
    with open(dir_path, "wb") as file:
        pickle.dump(baseline_contexts, file)

def load_baseline_contexts(dataset, batch_size, n_batches, baseline):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "baseline_contexts")
    dir_path = os.path.join(dir, f"bdctxt_bs_{batch_size}_nb_{n_batches}_{baseline}.pt")
    return torch.load(dir_path)

def filter_contexts(contexts, min_f_act=1, min_contexts=4): # filter out contexts that have less than min_f_act and min_contexts
    filtered_contexts = {}
    for f_id, context in contexts.items():
        if torch.tensor(context["max_score"]).mean() > min_f_act and len(context["context_string"]) > min_contexts:
            filtered_contexts[f_id] = context
    return filtered_contexts


def load_identity_relu_encoder(dataset, d_mlp):
    path = os.path.join("experiments", "dict_att", dataset, "dictionary", "relu.pt")
    if os.path.exists(path):
        return torch.load(path)
    else:
        relu = IdentityReLU(activation_size=d_mlp)
        torch.save(relu, path)
    return relu

def load_random_dict(dataset, d_mlp, dictionary_size):
    path = os.path.join("experiments", "dict_att", dataset, "dictionary", "random_dict.pt")
    if os.path.exists(path):
        return torch.load(path)
    else:
        random_dict = RandomDict(d_mlp, dictionary_size)
        torch.save(random_dict, path)
    return random_dict


if __name__ == "__main__":
    filter = True 
    dataset = "mimiciii_clean"
    n_classes = get_n_classes(dataset)
    finetune_batchsize = 16 # actually 8 regardless with our code, but its good that the memory requirements are okay with no gradient computation.
    gpu = get_gpu()
    device = torch.device(f"cuda:{gpu}")
    use_finetuned_model = True
    freeze_plm = False 
    projection_size = 768 
    recon_lambda = 1e-6
    lr = 5e-5
    dictionary_type = "L1"
    plm_path="RoBERTa-base-PM-M3-Voc-hf"
    alpha = 8
    d_mlp = 768
    num_epochs = 20
    run_id = 0
    baseline = get_baseline()

    n_batches = get_n_batches()
    print("N_BATCHES:", n_batches)
    test_loader, text_encoder, label_transform, text_transform = get_interpret_objs(dataset, finetune_batchsize)
    if baseline == "dma":
        classifier_head_type = "dma"
        model = load_dma_experiment(run_id, dataset, dictionary_type, device)
        model.to(device)
        my_top_contexts = get_all_dictionary_contexts_iterative(test_loader, model, text_transform, n_batches, device, buffer_size=100) # would be good to write all of this to a file
        filtered_contexts = filter_contexts(my_top_contexts)
        save_dictionary_contexts(dataset=dataset, dictionary_contexts=my_top_contexts, batch_size=finetune_batchsize, n_batches=n_batches)
        save_filtered_contexts(dataset=dataset, filtered_contexts=filtered_contexts, batch_size=finetune_batchsize, n_batches=n_batches)
    elif baseline == "RELU": # let's just do relu for now!
        relu = load_identity_relu_encoder(dataset, d_mlp)
        relu.to_device(device)
        plm_icd = load_plm_icd(plm_path, dataset, n_classes, device, use_finetuned_model)
        baseline_contexts = get_all_dictionary_contexts_baseline(test_loader, plm_icd, relu, text_transform, n_batches, device, buffer_size=100)
        save_baseline_contexts_fast(dataset, baseline_contexts, finetune_batchsize, n_batches, baseline)
    elif baseline == "RANDOM":
        random_dict = load_random_dict(dataset, d_mlp, alpha*d_mlp)
        random_dict.to_device(device)
        plm_icd = load_plm_icd(plm_path, dataset, n_classes, device, use_finetuned_model)
        baseline_contexts = get_all_dictionary_contexts_baseline(test_loader, plm_icd, random_dict, text_transform, n_batches, device, buffer_size=100)
        save_baseline_contexts_fast(dataset, baseline_contexts, finetune_batchsize, n_batches, baseline)

    print("SUCCESS!!!!")