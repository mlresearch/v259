import transformers
import torch
import os
import pandas as pd
import re
import json
import pickle
import random
from transformers import BitsAndBytesConfig
from cli import *
# Need to use correct environment for this task.
# Initialize the pipeline once
def generate_text(prompt, pipeline, max_new_tokens=256, temperature=0.00001, top_p=0.99):
    """
    Generate text using the specified prompt and parameters.

    Args:
        prompt (str): The input prompt for text generation.
        max_new_tokens (int, optional): The maximum number of new tokens to generate. Defaults to 256.
        temperature (float, optional): The temperature value for sampling. Defaults to 0.0.
        top_p (float, optional): The top-p value for sampling. Defaults to 0.9.

    Returns:
        str: The generated text.
    """


    messages = [
        {"role": "system", "content": "You are an expert and experienced from the healthcare and biomedical domain with extensive medical knowledge and practical experience. Your job is to help annotate specific tasks by looking for common patterns within text. Please answer the below message."},
        {"role": "user", "content": prompt},
    ]

    prompt = pipeline.tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    terminators = [
        pipeline.tokenizer.eos_token_id,
        pipeline.tokenizer.convert_tokens_to_ids("<|eot_id|>")
    ]


    outputs = pipeline(
        prompt,
        max_new_tokens=max_new_tokens,
        eos_token_id=terminators,
        do_sample=True,
        temperature=temperature,
        top_p=top_p,
    )

    return outputs[0]["generated_text"][len(prompt):]

def load_dictionary_contexts(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"dctxt_bs_{batch_size}_nb_{n_batches}.pt")
    print("Reading in contexts:", dir_path)
    return torch.load(dir_path)

def create_yes_no_question(context_strings):
    """
    Create a prompt from the specified list of context strings.

    Args:
        context_strings (list): A list of context strings.

    Returns:
        str: The generated prompt.
    """
    prompt = f""
    for context_string in context_strings:
        prompt += " ".join(context_string) + "\n"
    prompt += f"\nIs there a common pattern observed among these 4 contexts above? Respond with only one word yes or no.\n"
    return prompt

def create_dict_questions_yes_no(contexts_dictionary, topk=4):
    questions = {}
    for f_id, context_dict in contexts_dictionary.items():
        contexts = context_dict["context_string"][:topk]
        prompt = create_yes_no_question(contexts)
        questions[f_id] = prompt
        print(prompt)
    return questions

def create_description_question(context_strings):
    prompt = f""
    for context_string in context_strings:
        prompt += " ".join(context_string) + "\n"
    prompt += f"\n Describe the common pattern observed among these 4 contexts above. Think step by step. If there are common medical trends observed, or specific anatomy repeatedly used, please highlight those. Please respond with 8 words or less about the specific medical theme.\n"
    return prompt

def create_dict_questions_desc(contexts_dictionary, yes_dict, topk=4):
    questions = {}
    for f_id, context_dict in contexts_dictionary.items():
        if yes_dict[f_id]: 
            contexts = context_dict["context_string"][:topk]
            prompt = create_description_question(contexts)
            questions[f_id] = prompt # only store the ones that the LLM originally identified.
        else:
            questions[f_id] = None # if the LLM did not identify a common pattern, then we use this as extra information
    return questions

# Auto Identify all dictionary contexts and compute important metrics like total yes / total questions 
# store them in a dictionary 
def get_yes_no_responses(questions, pipeline):
    responses = {}
    n_yes = 0
    for f_id, question in questions.items():
        response = generate_text(question, pipeline)
        if "yes" in response: 
            n_yes +=1
            responses[f_id] = True
        else:
            responses[f_id] = False
        # print(response)
    return responses, n_yes

def get_description_responses(questions, pipeline):
    responses = {}
    for f_id, question in questions.items():
        if question:
            response = generate_text(question, pipeline)
            responses[f_id] = response
            # print(response)
    return responses

def extract_feature_summaries(description_responses):
    feature_summaries = {}
    pattern = r"The common pattern.*?(?:is|are)[\s'\"]*(.*?)(?:[.]|$)"
    for f_id, sentence in description_responses.items():
        match = re.search(pattern, sentence, re.IGNORECASE)
        if match:
            common_pattern = match.group(1)
            feature_summaries[f_id] = common_pattern
        else:
            feature_summaries[f_id] = None
    return feature_summaries

def get_random_context(fid, random_contexts):
    other_fids = list(random_contexts.keys())
    random_int = random.randint(0, len(other_fids)-1)
    while other_fids[random_int] == fid:
        random_int = random.randint(0, len(other_fids)-1)
    other_fid = other_fids[random_int]
    return random_contexts[other_fid]["context_string"][random.randint(0, len(random_contexts[other_fid]["context_string"])-1)]

def create_identification_experiment_questions(random_contexts, topk=4):
    questions = {}
    for f_id, context_dict in random_contexts.items():
        contexts = context_dict["context_string"][:topk].copy()
        random_context = get_random_context(f_id, random_contexts)
        contexts.append(random_context)
        random.shuffle(contexts)
        prompt = ""
        for idx, context in enumerate(contexts):
            prompt += f"Context {idx}: " + " ".join(context) + "\n"
        
        prompt += f"\nWhich context is different from the other contexts? Please reply with only the context number. \n"
        questions[f_id] = {"prompt": prompt, "truth": random_context, "contexts": contexts}
        print(prompt)
    return questions

# human is a bad descriptor, we're really just trying to compare to the human responses given the dataframe that we generated earlier for our human anntoators
def create_identification_question_human(contexts, topk=4):
    prompt = ""
    for idx, context in enumerate(contexts):
        prompt += f"Context {idx}: " + context +  "\n"
    prompt += f"\nWhich context is different from the other contexts? Please reply with only the context number. \n"
    print(prompt)
    return prompt

def create_description_question_human(contexts, topk=4):
    prompt = f""
    for context_string in contexts:
        prompt += " " + context_string+ "\n"
    prompt += f"\n Describe the common pattern observed among these 4 contexts above. Think step by step. If there are common medical trends observed, or specific anatomy repeatedly used, please highlight those. Please respond with 8 words or less about the specific medical theme.\n"
    return prompt

def identification_test(rand_identification_prompts, pipeline):
    responses = {}
    n_yes = 0
    for f_id, question in rand_identification_prompts.items():
        prompt = question["prompt"]
        contexts = question["contexts"]
        answer = question["truth"]
        response = generate_text(prompt, pipeline)
        match = re.search(r'\b\d+\b', response)
        if match: # only add to the number correct if match is found
            index_response = int(match.group(0)) 
            if contexts[index_response] == answer:
                responses[f_id] = True
                n_yes +=1
            else:
                responses[f_id] = False
        else:
            responses[f_id] = False
    return responses, n_yes

def identification_pipeline(contexts_dictionary, pipeline, topk=4, path=None):
    # step 1 identify all the yeses
    y_n_questions = create_identification_experiment_questions(contexts_dictionary, topk=topk)
    yes_dict, n_yes = identification_test(y_n_questions, pipeline)
    desc_dict_questions = create_dict_questions_desc(contexts_dictionary, yes_dict, topk=topk)
    # step 2 identify all the descriptions
    desc_dict = get_description_responses(desc_dict_questions, pipeline)
    # step 3 extract feature summaries
    feature_summaries = desc_dict
    print(f"Total Identification Accuracy: {n_yes} / {len(yes_dict)}")
    if path:
        with open(path, "w") as f:
            json.dump(feature_summaries, f, indent=4)
    return feature_summaries, n_yes


def restore_dict(data_dict):
    for key, value in data_dict.items():
        if isinstance(value, dict):
            data_dict[key] = restore_dict(value)
        elif isinstance(value, list):
            new_list = []
            for item in value:
                if isinstance(item, list):
                    if all(isinstance(x, float) for x in item):
                        new_list.append(torch.tensor(item, dtype=torch.float32))
                    elif all(isinstance(x, int) for x in item):
                        new_list.append(torch.tensor(item, dtype=torch.int64))
                    else:
                        new_list.append(item)
                else:
                    new_list.append(item)
            data_dict[key] = new_list
        elif isinstance(value, (float, int)):
            data_dict[key] = torch.tensor([value], dtype=torch.float32 if isinstance(value, float) else torch.int64)
    return data_dict

def load_dict_contexts_fast(dataset, batch_size, n_batches):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "dictionary_contexts")
    dir_path = os.path.join(dir, f"fast_dctxt_bs_{batch_size}_nb_{n_batches}.pkl")
    with open(dir_path, "rb") as file:
        dictionary_contexts = pickle.load(file)
    return restore_dict(dictionary_contexts)

def load_baseline_contexts_fast(dataset, batch_size, n_batches, baseline):
    dir = os.path.join("experiments", "dict_att", dataset, "dictionary", "baseline_contexts")
    dir_path = os.path.join(dir, f"fast_bctxt_bs_{batch_size}_nb_{n_batches}_{baseline}.pkl")
    with open(dir_path, "rb") as file:
        baseline_contexts = pickle.load(file)
    return restore_dict(baseline_contexts)

def load_baseline_contexts_df(dataset, baseline):
    path = f"experiments/dict_att/mimiciii_clean/dictionary/questions/sample_filtered_{baseline}_questions.csv"
    return pd.read_csv(path)


def reduce_baseline(contexts_dictionary):
    for fid, context_dict in contexts_dictionary.items():
        for i in range(len(context_dict["context_string"])):
            context = context_dict["context_string"][i]
            f_acts = context_dict["context_f_acts"][i]
            tokens = context_dict["context_tokens"][i]
            print(f_acts > 0 )
            # get nonzero indices
            values, indices = torch.sort(f_acts, descending=True)
            topk_indices = indices[:5] # top 5
            # sort those in ascending order to maintain order
            topk_indices = topk_indices.sort()[0]
            new_context_strings = []
            new_context_tokens = []
            new_f_acts = []
            for idx in topk_indices:
                new_context_strings.append(context[idx])
                new_context_tokens.append(tokens[idx])
                new_f_acts.append(f_acts[idx])
            context_dict["context_string"][i] = new_context_strings
            context_dict["context_tokens"][i] = new_context_tokens
            context_dict["context_f_acts"][i] = new_f_acts
            print(context_dict["context_string"][i])
    return contexts_dictionary  

if __name__ == "__main__":
    # model_id = "aaditya/OpenBioLLM-Llama3-8B"
    gpu = get_gpu()
    baseline = get_baseline()
    topk = get_topk()
    use_reduced = True
    compare_to_human = False
    device = f"cuda:{gpu}" if torch.cuda.is_available() else "cpu"
    nf4_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
    bnb_4bit_use_double_quant=True,
    bnb_4bit_compute_dtype=torch.bfloat16
    )
    model_id = "aaditya/OpenBioLLM-Llama3-70B"
    # model_nf4 = transformers.LlamaForCausalLM.from_pretrained(model_id, load_in_8bit=True, device_map="auto")
    model_nf4 = transformers.AutoModelForCausalLM.from_pretrained(model_id, 
                                                    quantization_config=nf4_config,
                                                    device_map={"": device})
    # tokenizer = transformers.LlamaTokenizer.from_pretrained(model_id)
    pipeline = transformers.pipeline(
        "text-generation",
        model= model_nf4, #model_id,
        # model_kwargs={"torch_dtype": torch.bfloat16},
        tokenizer=model_id,
        # device=device,
    )

    messages = [
        {"role": "system", "content": "You are an expert and experienced from the healthcare and biomedical domain with extensive medical knowledge and practical experience. Your name is OpenBioLLM, and your job is to annotate dictionary features and contexts learned by interpretability techniques. Please answer the below message."},
        {"role": "user", "content": "Hello?"},
    ]

    prompt = pipeline.tokenizer.apply_chat_template(
        messages,
        tokenize=False,
        add_generation_prompt=True
    )

    terminators = [
        pipeline.tokenizer.eos_token_id,
        pipeline.tokenizer.convert_tokens_to_ids("<|eot_id|>")
    ]

    outputs = pipeline(
        prompt,
        max_new_tokens=256,
        eos_token_id=terminators,
        do_sample=True,
        temperature=0.1,
        top_p=0.9,
    )

    dataset = "mimiciii_clean"
    print(outputs[0]["generated_text"][len(prompt):])
    print("LOADING CONTEXTS! Takes ~ 17 minutes.")
    contexts_dictionary = None
    if baseline == "L1":
        contexts_dictionary = load_dict_contexts_fast(dataset=dataset, batch_size=64, n_batches=None)
    elif baseline == "RANDOM":
        contexts_dictionary = load_baseline_contexts_fast(dataset=dataset, batch_size=8, n_batches=100, baseline="RANDOM") # may need to redo this one, or even hilariously do a quick sampling. 
    elif baseline == "RELU":   
        contexts_dictionary = load_baseline_contexts_fast(dataset=dataset, batch_size=16, n_batches=None, baseline="RELU_CLEAN")
    
    if (baseline == "RELU" or baseline == "RANDOM") and use_reduced:
         # take top 5 tokens instead for each context, and use that instead.
        contexts_dictionary = reduce_baseline(contexts_dictionary)
    print("SUCCESS IN LOADING CONTEXTS!")
    # we have to use the csv files here, because unfortunately that's what we had decided to do for our human evaluators 
    if compare_to_human:
        # load the sampled contexts instead
        df = load_baseline_contexts_df(dataset, baseline)
        # maybe we can reconstruct the original contexts dictionary from the dataframe
        responses = {}
        feature_summaries = {}
        n_yes = 0
        for index, row in df.iterrows():
            f_id = row["fid"]
            answer = row["random_context"]
            og_contexts = []
            for i in range(0, topk):
                if row[f"context{i}"] != answer:
                    og_contexts.append(row[f"context{i}"])
            contexts = []
            for i in range(0, topk):
                contexts.append(row[f"context{i}"])
            prompt = create_identification_question_human(contexts, topk=topk)
            response = generate_text(prompt, pipeline)
            match = re.search(r'\b\d+\b', response)
            if match: # only add to the number correct if match is found
                index_response = int(match.group(0)) 
                if contexts[index_response] == answer:
                    n_yes +=1
                    desc_question = create_description_question_human(og_contexts, topk=topk)
                    feature_summaries[f_id] = generate_text(desc_question, pipeline)
                else:
                    feature_summaries[f_id] = None
            else:
                feature_summaries[f_id] = None
                

        print(f"Total Identification Accuracy: {n_yes} / {len(responses)}")

        # now we need to generate the feature summaries using the og contexts, and save them
        path = f"experiments/dict_att/mimiciii_clean/dictionary/human_{baseline}_feature_summaries_top{topk}_reduced_{use_reduced}.json" 
        with open(path, "w") as f:
            json.dump(feature_summaries, f, indent=4)
            
    else:
        # because this also randomizes the random contexts, instead we have to make our own speicfic modified pipeline as well! AHHH WHY DID WE MAKE THIS HARDER ON OURSELVES!!!
        feature_summaries, n_yes = identification_pipeline(contexts_dictionary, pipeline, topk=topk, path=f"experiments/dict_att/mimiciii_clean/dictionary/{baseline}_feature_summaries_top{topk}_reduced_{use_reduced}.json")