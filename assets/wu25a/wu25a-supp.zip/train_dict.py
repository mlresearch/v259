import torch
import torch.nn as nn
import torch.nn.functional as F
import os
import json
import torch.nn.init as init
import optuna
from optuna.integration import PyTorchLightningPruningCallback
from torch.optim import Adam
from torchmetrics import Accuracy, F1Score
from functools import partial
import lightning.pytorch as pl
from cli import freeze_plm_icd, get_dataset, get_gpu, use_pretrained_dict, get_finetune_batchsize, use_finetuned_weights, get_experiment, load_chkpt, test, get_type, use_optuna, get_epochs
from lightning.pytorch.loggers import NeptuneLogger
from train import ensure_directory_exists
from data import get_original_datasets, print_gpu_memory_usage, print_memory_usage, get_n_classes
from lightning.pytorch.callbacks import EarlyStopping, LearningRateMonitor
from lightning.pytorch.loggers import TensorBoardLogger
from lightning.pytorch.callbacks import ModelCheckpoint
from train import load_plm_icd, PLMICD

def generate_prediction(logits):
    return torch.sigmoid(logits) > 0.35
def initialize_running_metrics(n_classes):
  return {
    "macro_f1": {
       "running_sum": torch.zeros(n_classes),
       "running_target_sum": torch.zeros(n_classes),
       "running_pred_sum": torch.zeros(n_classes)
    },
    "aenc_loss": 0,
    "logit_loss": 0,
    "avg_freq": 0
  }

def reconstruction_loss(original_logits, reconstructed_logits):
  loss_fxn = nn.L1Loss()
  return loss_fxn(reconstructed_logits, original_logits).item()

def compute_running_F1(running_metrics, eps=1e-9):
  running_sum = running_metrics["macro_f1"]["running_sum"]
  running_target_sum = running_metrics["macro_f1"]["running_target_sum"]
  running_pred_sum = running_metrics["macro_f1"]["running_pred_sum"]
  precision = running_sum / (running_pred_sum + eps)
  recall = running_sum / (running_target_sum + eps)
  f1 = 2 * (precision * recall) / (precision + recall + eps)
  return f1.mean().item()

def get_aggregated_metrics(running_metrics):
  scores = {}
  scores["Macro F1"] = compute_running_F1(running_metrics) 
  scores["Autoencoder Loss"] = running_metrics["aenc_loss"]
  scores["Reconstruction of Logits Loss"] = running_metrics["logit_loss"]
  # scores["Average Frequency of Feature"] = running_metrics["avg_freq"]
  return scores


def init_weights(m):
    if isinstance(m, nn.Linear):
        init.kaiming_uniform_(m.weight, nonlinearity='relu')

class DictionaryAutoEncoder(nn.Module):
    def __init__(self, d_mlp, d_hidden, l1_coeff, l2_coeff,  dtype=torch.float16):
        super(DictionaryAutoEncoder, self).__init__()

        # self.W_enc = nn.Parameter(torch.empty(d_mlp, d_hidden))
        # self.W_dec = nn.Parameter(torch.empty(d_hidden, d_mlp))
        # self.b_enc = nn.Parameter(torch.zeros(d_hidden))
        # self.b_dec = nn.Parameter(torch.zeros(d_mlp)), equivalent to the below.

        self.encoder = nn.Linear(d_mlp, d_hidden)
        self.decoder = nn.Linear(d_hidden, d_mlp)
        self.dict_size = d_hidden
        self.apply(init_weights)  # Initialize weights with Kaiming uniform and convert to float16

        self.d_mlp = d_mlp
        self.dict_size = d_hidden
        self.d_hidden = d_hidden
        self.l1_coeff = l1_coeff
        self.l2_coeff = l2_coeff

    def encode(self, x):
        return F.relu(self.encoder(x))

    def decode(self, f):
        return self.decoder(f)

    def forward(self, x, denoising=False, std = None):
        noise = 0
        if denoising:
            noise = torch.normal(0, std, size=x.size()).to(x.device)

        acts = self.encode(x + noise)
        x_reconstruct = self.decode(acts)

        recon_loss = (x_reconstruct - x).pow(2).sum(-1).mean(0)
        l1_loss = self.l1_coeff * acts.abs().sum().mean(0)
        l2_loss = self.l2_coeff * acts.square().sum().mean(0) # average over the batch
        loss = recon_loss + l1_loss + l2_loss # reconstruction + elastic net loss regularizationt erms
        loss = {"loss" : loss,
                "l1_loss" : l1_loss,
                "l2_loss" : l2_loss,
                "recon_loss" : recon_loss}
        
        return acts, x_reconstruct, loss

    def get_dictionary_value(self, id):
        return self.decoder.weight.T[id]
    
    def get_dictionary_matrix(self):
        return self.decoder.weight.T


# Two heads, a dictionary attention head and a label attention head
class DictionaryLabelAttention(nn.Module):
    #  ICD memory should be 1 x c x f in size, save in a torch tensor
    def __init__(self,dictionary : DictionaryAutoEncoder, input_size : int, dictionary_size, projection_size: int, num_classes: int, path_to_icd_memory : str, debug=False):
        super().__init__()

        self.dictionary = dictionary 
        self.dictionary_size = dictionary_size
        self.projection_size = projection_size 
        self.path_to_icd_memory = path_to_icd_memory
        self.icd_memory = nn.Parameter(torch.zeros(1, num_classes, dictionary_size))
        self.attn = None
        if not debug:
            icd_memory = torch.load(path_to_icd_memory)
            icd_memory = icd_memory.unsqueeze(0)
            self.icd_memory = nn.Parameter(icd_memory)
        else:
            self.icd_memory = nn.Parameter(torch.zeros(1, num_classes, dictionary_size))
        self.third_linear = nn.Linear(input_size, num_classes)

    def compute_dictionary_attention(self, x):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1) # should be b x s x f
        attention = f @ self.icd_memory.transpose(1,2).to(f.device) # b x s x f * 1 x f x c -> b x s x c 
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    def compute_modified_dictionary_attention(self, x, addition_mask=None, multiply_mask= None):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1) # should be b x s x f
        modified_icd_memory = self.icd_memory.data.clone()
        if multiply_mask is not None:
            modified_icd_memory *= multiply_mask
        if addition_mask is not None:
            modified_icd_memory += addition_mask
        attention = f @ modified_icd_memory.transpose(1,2).to(f.device) # b x s x f * 1 x f x c -> b x s x c 
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    def compute_dictionary_attention_ablated(self, x, f_ablate, icd_idx, use_precise=True):
        b,s,d = x.size()
        f, x_recon, aenc_loss_dict = self.dictionary(rearrange(x, 'b s d -> (b s) d'))
        f = f.view(b,s,-1)
       
        # iteratively go through each batch with a different icd_matrix effectively
        icd_matrices = []
        if use_precise:
            # Create a mask tensor for zeroing out the intersecting weights
            mask = torch.ones_like(self.icd_memory.transpose(1, 2))
            mask[:, f_ablate, icd_idx] = 0
            
            # Apply the mask to the icd_memory tensor
            icd_matrices = self.icd_memory.transpose(1, 2).to(f.device) * mask
        else:
            # Create a mask tensor for zeroing out the class memory vector
            mask = torch.ones_like(self.icd_memory.transpose(1, 2))
            mask[:, :, icd_idx] = 0
            
            # Apply the mask to the icd_memory tensor
            icd_matrices = self.icd_memory.transpose(1, 2).to(f.device) * mask

        attention = f @ icd_matrices
        attention = torch.nn.functional.softmax(attention, dim=1)
        return attention, aenc_loss_dict

    # f_ablate are the indices of dictionary features we want to remove for the specific ICD code
    def forward_ablated(self, x, f_ablate, icd_idx, use_precise=True):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_dictionary_attention_ablated(x, f_ablate, icd_idx, use_precise)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict


    def forward_modified(self, x, addition_mask=None, multiply_mask= None):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_modified_dictionary_attention(x, addition_mask, multiply_mask)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        self.attn = combined_attn
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict


    def forward(self, x):
        # get attention weights with label attention
        dictionary_attn_weights, aenc_loss_dict = self.compute_dictionary_attention(x)
        # combine the two attentions
        combined_attn = dictionary_attn_weights
        combined_attn = combined_attn.transpose(1,2)
        self.attn = combined_attn
        x = combined_attn @ x 
        return (
            self.third_linear.weight.mul(x)
            .sum(dim=2)
            .add(self.third_linear.bias)
        ), aenc_loss_dict
        # get attention weights with dictionary attention


def get_dictionary_paths(dataset : str, dictionary_type : str, alpha : int, finetuned_plm : bool):
    dictionary_directory = os.path.join("experiments", "dict_att", dataset, "dictionary", "chkpts", dictionary_type)
    chkpt_path = os.path.join(dictionary_directory, f"alpha_{alpha}_ft{int(finetuned_plm)}_{dictionary_type}_E10.pt")
    hyperparameters_path = os.path.join(dictionary_directory, f"alpha_{alpha}_ft{int(finetuned_plm)}_{dictionary_type}_E10.json")
    return chkpt_path, hyperparameters_path

    

def load_dictionary(dataset : str, dictionary_type : str, alpha : int, finetuned_plm : bool):
    chkpt_path, hyperparameters_path = get_dictionary_paths(dataset, dictionary_type, alpha, finetuned_plm)
    print("dictionary_path:", chkpt_path)
    print("hyperparameters_path:", hyperparameters_path)    
    params = get_hyperparameters(hyperparameters_path)
    if dictionary_type == "SPINE":
        return None
        # dictionary = SPINEAutoEncoder(d_mlp=768, d_hidden=params["alpha"] * 768, asl_coeff=params["asl"], psl_coeff=params["psl"])
        # dictionary.load_state_dict(torch.load(chkpt_path))
    else:
        dictionary = DictionaryAutoEncoder(d_mlp=768, d_hidden=params["alpha"] * 768, l1_coeff=params["l1_coeff"], l2_coeff=params["l2_coeff"])
        dictionary.load_state_dict(torch.load(chkpt_path))

    return dictionary, params
    

# save hyperparameters configuration to json with useful information!
def save_hyperparameters(hyperparameters, path):
    with open(path, 'w') as f:
        json.dump(hyperparameters, f)

def get_hyperparameters(path):
    try:
        with open(path, 'r') as f:
            params = json.load(f)
        return params
    except json.JSONDecodeError as e:
        print(f"Error loading hyperparameters: {e}")
        raise e


def get_validation_values(lm : PLMICD, dictionary, input_ids, attention_mask):
    logits = lm(input_ids, attention_mask=attention_mask).detach() # could this be the problem?
    hidden_out = lm.get_hidden_output(input_ids, attention_mask=attention_mask)
    batch_size, num_chunks, chunk_size = input_ids.size()
    acts, x_reconstruct, loss= dictionary(hidden_out.view(batch_size * num_chunks * chunk_size, -1))
    auto_encoder_loss = loss["loss"]
    reconstructed_logits = lm.get_reconstructed_logits(x_reconstruct.view(batch_size, num_chunks * chunk_size, -1))
    return logits.detach(), reconstructed_logits.detach(), acts.detach(), auto_encoder_loss.detach().item() 


# For training the dictionary first, then building the right modules around it.
class DictionaryPLMICDModule(pl.LightningModule):
    def __init__(self, dictionary, plm_icd : PLMICD, n_classes : int, lr=1e-5, denoising=False, std=None):
        super().__init__()
        self.dictionary = dictionary 
        self.lm = plm_icd
        self.val_step_outputs = initialize_running_metrics(n_classes) # for validation metrics
        self.test_step_outputs = initialize_running_metrics(n_classes) # for test metrics
        self.val_scores = {}
        self.lr = lr
        self.val_l0_norm = 0.0
        self.val_n_acts = 0
        self.n_classes = n_classes
        self.denoising = denoising
        self.std = std

    def forward(self, x):
        return self.dictionary(x)
    

    def training_step(self, batch, batch_idx):
        data, targets, attn_mask = batch.data, batch.targets, batch.attention_mask
        # print("HERE")
        b,c,nc = data.shape
        with torch.no_grad():
            plm_activations = self.lm.get_hidden_output(data, attention_mask=attn_mask).detach()

        # eliminate all the pads
        tokens_not_pad = data.flatten() != 1
        tokens_not_pad = torch.nonzero(tokens_not_pad).view(-1)
        plm_activations = plm_activations.view(b*c*nc, -1)[tokens_not_pad]
        L, d = plm_activations.shape
        n = 8096
        if L < n:
            n = L

        # Randomly sample for diverse token representation learning!
        indices = torch.randperm(L)[:n]
        plm_activations = plm_activations[indices]
        acts, x_reconstruct, loss = self.dictionary(plm_activations, self.denoising, self.std)
        self.log("L0_norm", (acts > 0).float().mean().item(), prog_bar=True, logger=True)
        for key, val in loss.items():
            self.log(key, val, prog_bar=True, logger=True)

        loss = loss["loss"] # return actual loss function
        return loss
    
    # validation loader will be the raw text id + attn mask loader to icd code
    @torch.no_grad()
    def validation_step(self, batch, batch_idx):
        data, targets, attn_mask = batch.data, batch.targets, batch.attention_mask
        logits, re_logits, f_acts, aenc_loss = get_validation_values(self.lm, self.dictionary, data, attn_mask)
        self.val_l0_norm += (f_acts > 0).float().sum().item() / self.dictionary.d_hidden # sum of all activated features seen (proportional to total features)
        self.val_n_acts += f_acts.size(0) # total number of features seen in val set
        # print("I am validating!!!")
        self.val_step_outputs["macro_f1"]["running_sum"] += (targets * generate_prediction(re_logits)).sum(dim=0).cpu()
        self.val_step_outputs["macro_f1"]["running_target_sum"] += targets.sum(dim=0).cpu()
        self.val_step_outputs["macro_f1"]["running_pred_sum"] += generate_prediction(re_logits).sum(dim=0).cpu()
        self.val_step_outputs["aenc_loss"] += aenc_loss
        self.val_step_outputs["logit_loss"] += reconstruction_loss(logits, re_logits)
        self.log("val_loss", aenc_loss, prog_bar=True, logger=True)
        return aenc_loss
    
    def on_validation_epoch_end(self):
        scores = get_aggregated_metrics(self.val_step_outputs)
        self.log("val:l0_norm", self.val_l0_norm / self.val_n_acts, prog_bar=True, logger=True)
        self.val_l0_norm = 0.0
        self.val_n_acts = 0.0
        for key, value in scores.items():
            self.log(f"val:{key}", value, prog_bar=True, logger=True, sync_dist=True)
        self.val_scores = scores
        self.val_step_outputs = initialize_running_metrics(self.n_classes) # reset again!
        print("Clearing Memory List!")
        print_memory_usage()

    @torch.no_grad()
    def test_step(self, batch, batch_idx):
        data, targets, attn_mask = batch.data, batch.targets, batch.attention_mask
        logits, re_logits, f_acts, aenc_loss = get_validation_values(self.lm, self.dictionary, data, attn_mask)
        self.test_step_outputs["macro_f1"]["running_sum"] += (targets.cuda() * generate_prediction(re_logits)).sum(dim=0).cpu()
        self.test_step_outputs["macro_f1"]["running_target_sum"] += targets.sum(dim=0).cpu()
        self.test_step_outputs["macro_f1"]["running_pred_sum"] += generate_prediction(re_logits).sum(dim=0).cpu()
        self.test_step_outputs["aenc_loss"] += aenc_loss
        self.test_step_outputs["logit_loss"] += reconstruction_loss(logits, re_logits)
        self.val_l0_norm += (f_acts > 0).float().sum().item() / self.dictionary.d_hidden # sum of all activated features seen (proportional to total features)
        self.val_n_acts += f_acts.size(0) # total number of features seen in val set
        self.log("test_loss", aenc_loss, prog_bar=True, logger=True)
        return aenc_loss

    @torch.no_grad()
    def on_test_epoch_end(self):
        
        self.log("test:l0_norm", self.val_l0_norm / self.val_n_acts, prog_bar=True, logger=True)
        self.val_l0_norm = 0.0
        self.val_n_acts = 0.0
        #scores = metrics.multilabel.multilabel_metrics_fn(labels, outputs, metrics=["accuracy", "hamming_loss", "f1_macro"])
        scores = get_aggregated_metrics(self.test_step_outputs)
        for key, value in scores.items():
            self.log(f"test:{key}", value, prog_bar=True, logger=True, sync_dist=True)
        print(scores)
        self.test_step_outputs = initialize_running_metrics(self.n_classes) # reset again!
    
    def configure_optimizers(self):
        # Define your optimizer (e.g., Adam optimizer)
        optimizer = torch.optim.AdamW(self.dictionary.parameters(), lr=self.lr, betas=(0,0.9999))
        return optimizer
    


def objective(trial : optuna.trial.Trial, 
              n_classes, 
              train_dataloader, 
              val_dataloader, 
              gpu,
              experiment_directory,
              dataset,
              plm_icd,
              finetuned_plm_icd) -> float: # dictionarty type indicates whether it was trained on the finetuned model or not.

    max_epochs = 10
    d_mlp = 768
    # Define the search space for hyperparameters
    lr = trial.suggest_loguniform("lr", 1e-7, 1e-4)
    l1_coeff = trial.suggest_loguniform("l1_coeff", 1e-5, 1e-2)
    l2_coeff = trial.suggest_loguniform("l2_coeff", 1e-5, 1e-2)
    alpha = trial.suggest_int("alpha", 8, 16)
    f_size = alpha * d_mlp # hardcoded
    # 
    chkpt_dir = os.path.join(experiment_directory, "chkpts")
    logs_dir = os.path.join(experiment_directory, "logs")
    ensure_directory_exists(chkpt_dir)
    ensure_directory_exists(logs_dir)
    filename = f"dict-alpha{alpha}-lr{lr}-l1{l1_coeff}-l2{l2_coeff}-{f_size}-{dataset}-ft{finetuned_plm_icd}-E{max_epochs}" # important to keep track of the hyperparameters
    # Create an instance of your model with the sampled hyperparameters
    dictionary = DictionaryAutoEncoder(d_mlp=d_mlp,
                                       d_hidden=f_size,
                                       l1_coeff=l1_coeff,
                                       l2_coeff=l2_coeff)
    
    model = DictionaryPLMICDModule(dictionary, plm_icd, n_classes = n_classes)

    logger = TensorBoardLogger(save_dir=logs_dir,
                               name=filename)
    
    checkpoint_callback = ModelCheckpoint(
        dirpath=chkpt_dir,
        filename=filename,
        save_top_k=1,
        verbose=True,
        monitor="val_loss",
        mode="min"
    )
    # Create a PyTorch Lightning trainer
    trainer = pl.Trainer(logger=logger,
                            accelerator="gpu",
                            enable_checkpointing=True,
                            benchmark=True, 
                            max_epochs=max_epochs, 
                            callbacks=[PyTorchLightningPruningCallback(trial, monitor="val_loss"), checkpoint_callback], 
                            devices=[gpu],
                            val_check_interval=0.98, 
                            fast_dev_run=False)

    # Train the model
    trainer.fit(model, train_dataloader, val_dataloader)

    optimization_metric = model.val_scores["Autoencoder Loss"]
    if finetuned_plm_icd:
        optimization_metric = model.val_scores["Macro F1"]
    # Return the validation metric to optimize
    return optimization_metric  # Replace "val_metric" with the appropriate validation metric from your model


def train_dictionary(dictionary_base_path, 
                     dictionary_type, 
                     plm_icd, 
                     alpha,
                     lr, 
                     l1_coeff, 
                     l2_coeff, 
                     gpu, 
                     dataset,
                     num_classes,
                     train_loader, 
                     val_loader, 
                     finetuned_plm_icd,
                     denoising, 
                     std,
                     max_epochs,
                     logger,
                     dev) -> tuple[DictionaryAutoEncoder, float]: 
    
    print("Training Dictionary!")
    d_mlp = 768
    f_size = alpha * d_mlp # hardcoded
    dictionary = DictionaryAutoEncoder(d_mlp=d_mlp,
                                       d_hidden=f_size,
                                       l1_coeff=l1_coeff,
                                       l2_coeff=l2_coeff)
    
    pl_module = DictionaryPLMICDModule(dictionary, plm_icd, n_classes = num_classes, denoising = denoising, std = std)

    chkpt_dir = os.path.join(dictionary_base_path, "chkpts", str(dictionary_type))
    logs_dir = os.path.join(dictionary_base_path, "logs", str(dictionary_type))
    filename = f"dict-alpha{alpha:.3f}-lr{lr:.3f}-l1{l1_coeff:.3f}-l2{l2_coeff:.3f}-{f_size}-{dataset}-{dictionary_type}-ft{int(finetuned_plm_icd)}" # important to keep track of the hyperparameters
    ensure_directory_exists(chkpt_dir)
    ensure_directory_exists(logs_dir)
    
    checkpoint_callback = ModelCheckpoint(
        dirpath=chkpt_dir,
        filename=filename,
        save_top_k=1,
        verbose=True,
        monitor="val_loss",
        mode="min"
    )
    
    # early_stopping_callback = EarlyStopping(monitor='val_loss', patience=2, mode="min", verbose=True, check_on_train_epoch_end=True)
    # logger = TensorBoardLogger(save_dir=logs_dir,
    #                            name=filename)
    
    trainer = pl.Trainer(logger=logger,
                            accelerator="gpu",
                            enable_checkpointing=True,
                            benchmark=True, 
                            max_epochs=max_epochs, 
                            callbacks=[checkpoint_callback], 
                            devices=[gpu],
                            val_check_interval=1.0, 
                            fast_dev_run=dev)
    
    trainer.fit(pl_module, train_loader, val_loader)
    trainer.test(pl_module, val_loader) # bc for whateever reason validation steps doesn't exist!
    final_loss = 100000000
    if finetuned_plm_icd:
        final_loss = pl_module.val_scores["Macro F1"]
    else:
        final_loss = pl_module.val_scores["Autoencoder Loss"]
    val_loss = final_loss
    return pl_module.dictionary, val_loss



##### MAIN #####


if __name__ == "__main__":

    gpu = get_gpu()
    dataset = get_dataset()
    n_classes = get_n_classes(dataset)
    use_finetuned_model = use_finetuned_weights()
    dictionary_trained = use_pretrained_dict()
    finetune_batchsize = get_finetune_batchsize() # we'll just reuse this for the dictionary training
    dictionary_type = get_type()
    hyperparameter_tune = use_optuna()
    num_epochs = get_epochs()
    denoising = True
    dev = False
    std = 0.1 # w2vec, maybe let's just see what happens when you do this
    experiment_directory = os.path.join("experiments", "dict_att", dataset, "dictionary")
    ensure_directory_exists(experiment_directory)
    plm_path="RoBERTa-base-PM-M3-Voc-hf"
    device = torch.device(f"cuda:{gpu}" if torch.cuda.is_available() else "cpu")
    train_loader, val_loader, test_loader = get_original_datasets(dataset, batch_size=finetune_batchsize)
    plm_icd = load_plm_icd(plm_path, dataset, n_classes, device, use_finetuned_model)

    best_hyperparameters = {}
    if hyperparameter_tune:
        pruner = optuna.pruners.MedianPruner() 
        study = optuna.create_study(direction="maximize", pruner=pruner)
        objective = partial(objective, 
                        n_classes=n_classes, 
                        train_dataloader = train_loader, 
                        val_dataloader = val_loader, 
                        gpu = gpu,
                        experiment_directory = experiment_directory,
                        dataset = dataset,
                        plm_icd = plm_icd,
                        finetuned_plm_icd = use_finetuned_model)
        study.optimize(objective, 5) # 5 different hyperparameters to try out, because why not
        print("Best trial:")
        trial = study.best_trial
        best_hyperparameters = study.best_trial.params
        print("Best hyperparameters:", best_hyperparameters)
    else: # my hyperparameters I want to quickly validate!
        alpha = 8
        if dictionary_type == "SPINE":
            print("USING SPINE!")
            best_hyperparameters = {
                "alpha" : alpha, # sticking with 8 now
                "lr" : 1e-6,
                "asl" : 1,
                "psl": 1
            }
        else:
            best_hyperparameters = {
                "alpha": alpha,
                "lr": 0.0001,
                "l1_coeff" : 0.0001,
                "l2_coeff" : 0
            }
    print("Training with hyperparameters:", best_hyperparameters)


    tags = ["Dictionary Training", dataset, dictionary_type, "finetuned" if use_finetuned_model else "not_finetuned", "denoising" if denoising else "not_denoising", "std", str(std)]
    neptune_logger = None # insert your logger here.[]
    neptune_logger.log_hyperparams(best_hyperparameters)

    dictionary = None
    if dictionary_type == "SPINE":
        exit(0)
    else:
        dictionary, final_val_loss = train_dictionary(
            dictionary_base_path=experiment_directory,
            dictionary_type=dictionary_type,
            plm_icd=plm_icd,
            alpha=best_hyperparameters["alpha"],
            lr=best_hyperparameters["lr"],
            l1_coeff=best_hyperparameters["l1_coeff"],
            l2_coeff=best_hyperparameters["l2_coeff"],
            gpu=gpu,
            dataset=dataset,
            num_classes=n_classes,
            train_loader=train_loader,
            val_loader=val_loader,
            finetuned_plm_icd=use_finetuned_model,
            denoising = denoising, 
            std = std,
            max_epochs = num_epochs,
            logger=neptune_logger,
            dev=dev
        )
    alpha = best_hyperparameters["alpha"]
    best_hyperparameters["epochs"] = num_epochs
    dictionary_path, hyperparameters_path = get_dictionary_paths(dataset, dictionary_type, alpha, use_finetuned_model)
    torch.save(dictionary.state_dict(), dictionary_path) # save the dictionary!

    print("returning with macro f1:", final_val_loss)
    best_hyperparameters["final_val_loss"] = final_val_loss
    save_hyperparameters(best_hyperparameters, hyperparameters_path)
    